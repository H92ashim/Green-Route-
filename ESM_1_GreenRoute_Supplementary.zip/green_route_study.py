#!/usr/bin/env python3
"""Calibrated benchmark and queueing simulation for the Green-Route study."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import math
import multiprocessing
import os
import platform
import plistlib
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
import numpy as np
import pandas as pd
from scipy.stats import qmc


MODEL_TIERS = {
    "compact": "tinyllama:latest",
    "mid": "llama3.2:3b",
    "large": "llama3.1:8b",
}
COMPLEXITIES = ("simple", "moderate", "complex")
STRATEGIES = (
    "large_only",
    "mid_default",
    "fixed_threshold",
    "quality_cascade",
    "green_route",
    "oracle",
)
STRATEGY_LABELS = {
    "large_only": "Large only",
    "mid_default": "Mid default",
    "fixed_threshold": "Fixed threshold",
    "quality_cascade": "Quality cascade",
    "green_route": "Green-Route",
    "oracle": "Oracle",
}
TIER_ORDER = ("compact", "mid", "large")
COLOURS = {
    "large_only": "#D55E00",
    "mid_default": "#CC79A7",
    "fixed_threshold": "#0072B2",
    "quality_cascade": "#E69F00",
    "green_route": "#009E73",
    "oracle": "#000000",
}
HATCHES = {
    "large_only": "///",
    "mid_default": "\\\\\\",
    "fixed_threshold": "xx",
    "quality_cascade": "..",
    "green_route": "++",
    "oracle": "",
}
MARKERS = {
    "large_only": "s",
    "mid_default": "^",
    "fixed_threshold": "D",
    "quality_cascade": "P",
    "green_route": "o",
    "oracle": "X",
}


@dataclass
class BenchmarkResult:
    model_tier: str
    model_name: str
    repetition: int
    prompt_id: str
    complexity: str
    max_output_tokens: int
    safety_critical: bool
    prompt_tokens: int
    output_tokens: int
    wall_seconds: float
    ollama_total_seconds: float
    prompt_eval_seconds: float
    eval_seconds: float
    tokens_per_second: float
    batch_mean_cpu_gpu_w: float
    batch_idle_adjusted_w: float
    gross_energy_wh: float
    dynamic_energy_wh: float
    response: str


def load_prompts(path: Path) -> list[dict[str, Any]]:
    prompts = json.loads(path.read_text(encoding="utf-8"))
    if len(prompts) != 30:
        raise ValueError("The controlled benchmark must contain exactly 30 prompts")
    counts = pd.Series([item["complexity"] for item in prompts]).value_counts()
    if any(counts.get(level, 0) != 10 for level in COMPLEXITIES):
        raise ValueError("The benchmark must contain ten prompts per complexity class")
    return prompts


def ollama_generate(
    base_url: str,
    model: str,
    prompt: str,
    max_tokens: int,
    timeout: int = 900,
) -> dict[str, Any]:
    body = json.dumps(
        {
            "model": model,
            "prompt": prompt,
            "stream": False,
            "keep_alive": "30m",
            "options": {
                "temperature": 0,
                "seed": 42,
                "num_predict": max_tokens,
                "num_ctx": 4096,
            },
        }
    ).encode("utf-8")
    request = urllib.request.Request(
        f"{base_url.rstrip('/')}/api/generate",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def check_ollama(base_url: str) -> list[dict[str, Any]]:
    try:
        with urllib.request.urlopen(f"{base_url.rstrip('/')}/api/tags", timeout=5) as response:
            models = json.loads(response.read().decode("utf-8"))["models"]
            available = {item["name"] for item in models}
    except (urllib.error.URLError, TimeoutError) as exc:
        raise RuntimeError(
            "Ollama is not running. Start it with `ollama serve` before benchmarking."
        ) from exc
    missing = [model for model in MODEL_TIERS.values() if model not in available]
    if missing:
        raise RuntimeError(f"Missing required Ollama models: {', '.join(missing)}")
    return models


def split_plists(raw: bytes) -> list[Any]:
    records = []
    for fragment in raw.split(b"\x00"):
        fragment = fragment.strip()
        if not fragment:
            continue
        try:
            records.append(plistlib.loads(fragment))
        except Exception:
            continue
    return records


def recursive_numeric_values(value: Any, path: str = "") -> Iterable[tuple[str, float]]:
    if isinstance(value, dict):
        for key, child in value.items():
            yield from recursive_numeric_values(child, f"{path}/{key}".lower())
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from recursive_numeric_values(child, f"{path}/{index}".lower())
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        yield path, float(value)


def extract_power_samples(path: Path) -> pd.DataFrame:
    records = split_plists(path.read_bytes())
    rows: list[dict[str, float]] = []
    for record in records:
        cpu_candidates: list[float] = []
        gpu_candidates: list[float] = []
        for key_path, number in recursive_numeric_values(record):
            if "power" not in key_path:
                continue
            if "cpu" in key_path and "gpu" not in key_path:
                cpu_candidates.append(number)
            elif "gpu" in key_path:
                gpu_candidates.append(number)
        if not cpu_candidates and not gpu_candidates:
            continue
        cpu = max(cpu_candidates, default=0.0)
        gpu = max(gpu_candidates, default=0.0)
        # powermetrics reports subsystem power in milliwatts.
        rows.append({"cpu_w": cpu / 1000.0, "gpu_w": gpu / 1000.0})
    result = pd.DataFrame(rows)
    if result.empty:
        raise RuntimeError(f"No CPU/GPU power samples were parsed from {path}")
    result["total_w"] = result["cpu_w"] + result["gpu_w"]
    return result


class PowerLogger:
    def __init__(self, output: Path, sample_ms: int, sudo: bool | None = None):
        self.output = output
        self.sample_ms = sample_ms
        self.sudo = os.geteuid() != 0 if sudo is None else sudo
        self.process: subprocess.Popen[bytes] | None = None
        self.warmup_samples = max(1, math.ceil(1000 / sample_ms))

    def __enter__(self) -> "PowerLogger":
        command = []
        if self.sudo:
            command.extend(["sudo", "-n"])
        command.extend(
            [
                "powermetrics",
                "--sample-rate",
                str(self.sample_ms),
                "--sample-count",
                "-1",
                "--buffer-size",
                "1",
                "--samplers",
                "cpu_power,gpu_power",
                "--format",
                "plist",
                "--output-file",
                str(self.output),
            ]
        )
        self.process = subprocess.Popen(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )
        time.sleep(max(1.0, self.sample_ms / 500.0))
        if self.process.poll() is not None:
            error = self.process.stderr.read().decode("utf-8", errors="replace")
            raise RuntimeError(
                "powermetrics could not start. Run `sudo -v` in a terminal first. "
                + error.strip()
            )
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        if self.process and self.process.poll() is None:
            self.process.send_signal(signal.SIGINT)
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.terminate()
                self.process.wait(timeout=5)


def benchmark(args: argparse.Namespace) -> None:
    available_models = check_ollama(args.ollama_url)
    prompts = load_prompts(args.prompts)
    output_dir: Path = args.output_dir
    power_dir = output_dir / "power_logs"
    output_dir.mkdir(parents=True, exist_ok=True)
    power_dir.mkdir(parents=True, exist_ok=True)

    idle_log = power_dir / "idle.plist"
    print(f"Measuring {args.idle_seconds}s idle power...")
    with PowerLogger(idle_log, args.sample_ms):
        time.sleep(args.idle_seconds)
    idle_samples = extract_power_samples(idle_log)
    idle_samples = idle_samples.iloc[
        min(len(idle_samples) - 1, max(0, math.ceil(1000 / args.sample_ms))) :
    ].reset_index(drop=True)
    idle_w = float(idle_samples["total_w"].mean())
    print(f"Idle CPU+GPU power: {idle_w:.3f} W")

    rows: list[BenchmarkResult] = []
    for tier, model in MODEL_TIERS.items():
        print(f"Warming {model}...")
        ollama_generate(
            args.ollama_url,
            model,
            prompts[0]["prompt"],
            prompts[0]["max_output_tokens"],
        )
        for repetition in range(1, args.repetitions + 1):
            power_log = power_dir / f"{tier}_rep{repetition}.plist"
            provisional: list[dict[str, Any]] = []
            with PowerLogger(power_log, args.sample_ms) as logger:
                measurement_start = time.perf_counter()
                for prompt in prompts:
                    start_offset = time.perf_counter() - measurement_start
                    started = time.perf_counter()
                    response = ollama_generate(
                        args.ollama_url,
                        model,
                        prompt["prompt"],
                        int(prompt["max_output_tokens"]),
                    )
                    wall = time.perf_counter() - started
                    end_offset = time.perf_counter() - measurement_start
                    provisional.append(
                        {
                            "prompt": prompt,
                            "response": response,
                            "wall": wall,
                            "start_offset": start_offset,
                            "end_offset": end_offset,
                        }
                    )
                batch_wall = time.perf_counter() - measurement_start
            power = extract_power_samples(power_log)
            measurement_power = power.iloc[logger.warmup_samples :].reset_index(
                drop=True
            )
            if measurement_power.empty:
                raise RuntimeError(f"Too few power samples in {power_log}")
            mean_w = float(measurement_power["total_w"].mean())
            dynamic_w = max(mean_w - idle_w, 0.0)
            print(
                f"{tier} repetition {repetition}: {batch_wall:.1f}s, "
                f"{mean_w:.2f} W gross, {dynamic_w:.2f} W above idle"
            )
            for item in provisional:
                prompt = item["prompt"]
                response = item["response"]
                wall = float(item["wall"])
                first_sample = max(
                    0, int(math.floor(item["start_offset"] * 1000 / args.sample_ms))
                )
                last_sample = max(
                    first_sample + 1,
                    int(math.ceil(item["end_offset"] * 1000 / args.sample_ms)),
                )
                prompt_power = measurement_power.iloc[first_sample:last_sample]
                if prompt_power.empty:
                    prompt_power = measurement_power.iloc[
                        min(first_sample, len(measurement_power) - 1) :
                        min(first_sample, len(measurement_power) - 1) + 1
                    ]
                prompt_mean_w = float(prompt_power["total_w"].mean())
                prompt_dynamic_w = max(prompt_mean_w - idle_w, 0.0)
                output_tokens = int(response.get("eval_count", 0))
                eval_seconds = float(response.get("eval_duration", 0)) / 1e9
                rows.append(
                    BenchmarkResult(
                        model_tier=tier,
                        model_name=model,
                        repetition=repetition,
                        prompt_id=prompt["id"],
                        complexity=prompt["complexity"],
                        max_output_tokens=int(prompt["max_output_tokens"]),
                        safety_critical=bool(prompt["safety_critical"]),
                        prompt_tokens=int(response.get("prompt_eval_count", 0)),
                        output_tokens=output_tokens,
                        wall_seconds=wall,
                        ollama_total_seconds=float(response.get("total_duration", 0)) / 1e9,
                        prompt_eval_seconds=float(response.get("prompt_eval_duration", 0))
                        / 1e9,
                        eval_seconds=eval_seconds,
                        tokens_per_second=output_tokens / eval_seconds
                        if eval_seconds > 0
                        else math.nan,
                        batch_mean_cpu_gpu_w=prompt_mean_w,
                        batch_idle_adjusted_w=prompt_dynamic_w,
                        gross_energy_wh=prompt_mean_w * wall / 3600.0,
                        dynamic_energy_wh=prompt_dynamic_w * wall / 3600.0,
                        response=response.get("response", ""),
                    )
                )

    raw = pd.DataFrame([asdict(row) for row in rows])
    expected_rows = len(MODEL_TIERS) * args.repetitions * len(prompts)
    if len(raw) != expected_rows:
        raise AssertionError(
            f"Expected {expected_rows} benchmark rows, obtained {len(raw)}"
        )
    if (raw["output_tokens"] <= 0).any():
        raise AssertionError("Every benchmark call must generate output tokens")
    if (raw["dynamic_energy_wh"] < 0).any():
        raise AssertionError("Idle-adjusted energy cannot be negative")
    raw.to_csv(output_dir / "benchmark_raw.csv", index=False)
    idle_samples.to_csv(output_dir / "idle_power_samples.csv", index=False)
    calibration = fit_calibration(raw, args.bootstrap_replicates, args.seed)
    calibration["benchmark_protocol"] = {
        "prompts": len(prompts),
        "repetitions": args.repetitions,
        "idle_seconds": args.idle_seconds,
        "sample_ms": args.sample_ms,
        "temperature": 0,
        "generation_seed": 42,
        "bootstrap_replicates": args.bootstrap_replicates,
        "processing_seed": args.seed,
    }
    (output_dir / "calibration.json").write_text(
        json.dumps(calibration, indent=2), encoding="utf-8"
    )
    pd.DataFrame(calibration["summary_rows"]).to_csv(
        output_dir / "calibration_summary.csv", index=False
    )
    model_rows = []
    for tier, outcomes in calibration["fitted_models"].items():
        for outcome, model in outcomes.items():
            for index, name in enumerate(model["coefficient_names"]):
                model_rows.append(
                    {
                        "model_tier": tier,
                        "outcome": outcome,
                        "coefficient": name,
                        "estimate": model["coefficients"][index],
                        "ci95_low": model["coefficient_ci95"][index][0],
                        "ci95_high": model["coefficient_ci95"][index][1],
                        "residual_sd": model["residual_sd"],
                        "r_squared": model["r_squared"],
                    }
                )
    pd.DataFrame(model_rows).to_csv(
        output_dir / "calibration_models.csv", index=False
    )
    metadata = {
        "python": sys.version,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "models": [
            item
            for item in available_models
            if item.get("name") in MODEL_TIERS.values()
        ],
        "prompt_file_sha256": hashlib.sha256(
            args.prompts.read_bytes()
        ).hexdigest(),
        "script_sha256": hashlib.sha256(
            Path(__file__).read_bytes()
        ).hexdigest(),
        "power_sampler": "Apple powermetrics CPU and GPU power",
        "power_interval_ms": args.sample_ms,
        "energy_boundary": "CPU and GPU dynamic energy above measured idle",
    }
    (output_dir / "benchmark_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    print(f"Calibration written to {output_dir / 'calibration.json'}")


def fit_calibration(
    raw: pd.DataFrame, bootstrap_replicates: int, seed: int
) -> dict[str, Any]:
    rng = np.random.default_rng(seed)
    summary_rows: list[dict[str, Any]] = []
    tiers: dict[str, Any] = {}
    fitted_models: dict[str, Any] = {}
    for tier in TIER_ORDER:
        tier_data = raw[raw["model_tier"] == tier].copy()
        tier_summary: dict[str, Any] = {}
        for complexity in COMPLEXITIES:
            values = tier_data[tier_data["complexity"] == complexity]
            energy = values["dynamic_energy_wh"].to_numpy(float)
            latency = values["wall_seconds"].to_numpy(float)
            throughput = values["tokens_per_second"].replace(
                [np.inf, -np.inf], np.nan
            ).dropna().to_numpy(float)

            def boot_interval(array: np.ndarray) -> tuple[float, float]:
                samples = rng.choice(
                    array, size=(bootstrap_replicates, len(array)), replace=True
                ).mean(axis=1)
                low, high = np.percentile(samples, [2.5, 97.5])
                return float(low), float(high)

            energy_ci = boot_interval(energy)
            latency_ci = boot_interval(latency)
            throughput_ci = boot_interval(throughput)
            item = {
                "n": int(len(values)),
                "energy_wh_mean": float(energy.mean()),
                "energy_wh_sd": float(energy.std(ddof=1)),
                "energy_wh_ci95": list(energy_ci),
                "latency_s_mean": float(latency.mean()),
                "latency_s_sd": float(latency.std(ddof=1)),
                "latency_s_ci95": list(latency_ci),
                "tokens_per_s_mean": float(throughput.mean()),
                "tokens_per_s_ci95": list(throughput_ci),
                "mean_prompt_tokens": float(values["prompt_tokens"].mean()),
                "mean_output_tokens": float(values["output_tokens"].mean()),
            }
            tier_summary[complexity] = item
            summary_rows.append(
                {
                    "model_tier": tier,
                    "complexity": complexity,
                    **{key: value for key, value in item.items() if not isinstance(value, list)},
                    "energy_ci_low": energy_ci[0],
                    "energy_ci_high": energy_ci[1],
                    "latency_ci_low": latency_ci[0],
                    "latency_ci_high": latency_ci[1],
                }
            )
        tiers[tier] = tier_summary
        predictors = np.column_stack(
            [
                np.ones(len(tier_data)),
                tier_data["prompt_tokens"].to_numpy(float),
                tier_data["output_tokens"].to_numpy(float),
            ]
        )
        model_summary: dict[str, Any] = {}
        for outcome in ("dynamic_energy_wh", "wall_seconds"):
            observed = tier_data[outcome].to_numpy(float)
            coefficients = np.linalg.lstsq(predictors, observed, rcond=None)[0]
            fitted = predictors @ coefficients
            residual_sd = float(np.std(observed - fitted, ddof=3))
            bootstrap_coefficients = np.empty((bootstrap_replicates, 3))
            for replicate in range(bootstrap_replicates):
                indices = rng.integers(0, len(tier_data), len(tier_data))
                bootstrap_coefficients[replicate] = np.linalg.lstsq(
                    predictors[indices], observed[indices], rcond=None
                )[0]
            intervals = np.percentile(
                bootstrap_coefficients, [2.5, 97.5], axis=0
            ).T
            model_summary[outcome] = {
                "coefficient_names": [
                    "intercept",
                    "prompt_token",
                    "output_token",
                ],
                "coefficients": coefficients.tolist(),
                "coefficient_ci95": intervals.tolist(),
                "residual_sd": residual_sd,
                "r_squared": float(
                    1.0
                    - np.sum((observed - fitted) ** 2)
                    / np.sum((observed - observed.mean()) ** 2)
                ),
            }
        fitted_models[tier] = model_summary
    return {
        "measurement_scope": "Apple M1 Pro same-device calibration",
        "energy_definition": "CPU+GPU dynamic energy above measured idle",
        "quality_source": "synthetic probabilistic service-adequacy model",
        "tiers": tiers,
        "fitted_models": fitted_models,
        "summary_rows": summary_rows,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    benchmark_parser = subparsers.add_parser("benchmark")
    benchmark_parser.add_argument(
        "--prompts", type=Path, default=Path("tourism_benchmark_prompts.json")
    )
    benchmark_parser.add_argument(
        "--output-dir", type=Path, default=Path("calibration")
    )
    benchmark_parser.add_argument("--ollama-url", default="http://127.0.0.1:11434")
    benchmark_parser.add_argument("--repetitions", type=int, default=5)
    benchmark_parser.add_argument("--idle-seconds", type=int, default=20)
    benchmark_parser.add_argument("--sample-ms", type=int, default=500)
    benchmark_parser.add_argument("--bootstrap-replicates", type=int, default=2000)
    benchmark_parser.add_argument("--seed", type=int, default=42)
    benchmark_parser.set_defaults(function=benchmark)

    simulate_parser = subparsers.add_parser("simulate")
    simulate_parser.add_argument(
        "--calibration", type=Path, default=Path("calibration/calibration.json")
    )
    simulate_parser.add_argument(
        "--output-dir", type=Path, default=Path("study_outputs")
    )
    simulate_parser.add_argument("--draws", type=int, default=200)
    simulate_parser.add_argument("--replications", type=int, default=10)
    simulate_parser.add_argument("--seed", type=int, default=42)
    simulate_parser.add_argument(
        "--workers",
        type=int,
        default=max(1, min(7, (os.cpu_count() or 2) - 1)),
    )
    simulate_parser.add_argument(
        "--adequacy-form",
        choices=sorted(ADEQUACY_FORMS),
        default=BASELINE_ADEQUACY_FORM,
    )
    simulate_parser.set_defaults(function=simulate)

    sweep_parser = subparsers.add_parser("adequacy-form-sweep")
    sweep_parser.add_argument(
        "--calibration", type=Path, default=Path("calibration/calibration.json")
    )
    sweep_parser.add_argument(
        "--output-dir", type=Path, default=Path("study_outputs")
    )
    sweep_parser.add_argument("--draws", type=int, default=200)
    sweep_parser.add_argument("--replications", type=int, default=10)
    sweep_parser.add_argument("--seed", type=int, default=42)
    sweep_parser.add_argument(
        "--workers",
        type=int,
        default=max(1, min(7, (os.cpu_count() or 2) - 1)),
    )
    sweep_parser.add_argument(
        "--forms", nargs="*", choices=sorted(ADEQUACY_FORMS), default=None
    )
    sweep_parser.add_argument(
        "--baseline-form",
        choices=sorted(ADEQUACY_FORMS),
        default=BASELINE_ADEQUACY_FORM,
    )
    sweep_parser.set_defaults(function=adequacy_form_sweep)

    stability_parser = subparsers.add_parser("form-stability")
    stability_parser.add_argument(
        "--output-dir", type=Path, default=Path("study_outputs")
    )
    stability_parser.add_argument(
        "--baseline-form",
        choices=sorted(ADEQUACY_FORMS),
        default=BASELINE_ADEQUACY_FORM,
    )
    stability_parser.set_defaults(function=form_stability)

    baseline_parser = subparsers.add_parser("baseline-analysis")
    baseline_parser.add_argument(
        "--output-dir", type=Path, default=Path("study_outputs")
    )
    baseline_parser.set_defaults(function=baseline_analysis)
    return parser.parse_args()


SCENARIOS = {
    "off_peak": {
        "label": "Off-peak",
        "daily_volume": 5_000,
        "complexity": (0.70, 0.22, 0.08),
        "safety_base": 0.002,
        "surge_hours": (),
    },
    "peak_season": {
        "label": "Peak season",
        "daily_volume": 50_000,
        "complexity": (0.46, 0.36, 0.18),
        "safety_base": 0.003,
        "surge_hours": (),
    },
    "festival_surge": {
        "label": "Festival surge",
        "daily_volume": 100_000,
        "complexity": (0.68, 0.25, 0.07),
        "safety_base": 0.005,
        "surge_hours": (15, 22),
    },
    "safety_disruption": {
        "label": "Safety disruption",
        "daily_volume": 60_000,
        "complexity": (0.58, 0.25, 0.17),
        "safety_base": 0.015,
        "surge_hours": (16, 20),
    },
}

BASE_ABILITY = {"compact": 0.50, "mid": 0.70, "large": 0.88}
DIFFICULTY_POINTS = {
    "simple": (0.20, 0.34, 0.48),
    "moderate": (0.43, 0.58, 0.72),
    "complex": (0.66, 0.79, 0.90),
}
DIFFICULTY_WEIGHTS = (0.25, 0.50, 0.25)
INPUT_TOKEN_FACTORS = (0.80, 1.00, 1.25)
OUTPUT_TOKEN_FACTORS = (0.75, 1.00, 1.35)
PREDICTION_Z_POINTS = (-1.2816, -0.5244, 0.0, 0.5244, 1.2816)
PREDICTION_Z_WEIGHTS = (0.10, 0.20, 0.40, 0.20, 0.10)
SLA_SECONDS = {"simple": 15.0, "moderate": 35.0, "complex": 75.0}
QUALITY_TARGET = {"simple": 0.80, "moderate": 0.84, "complex": 0.88}
BASE_WORKERS = {"compact": 3, "mid": 8, "large": 12}
PARAMETER_SPECS = (
    ("energy_multiplier", 0.85, 1.15, "Measured energy multiplier", "0.85 to 1.15"),
    ("latency_multiplier", 0.85, 1.15, "Measured latency multiplier", "0.85 to 1.15"),
    ("edge_ci", 0.05, 0.55, "Edge carbon intensity", "0.05 to 0.55 kg CO$_2$e/kWh"),
    ("cloud_ci", 0.04, 0.45, "Hosted carbon intensity", "0.04 to 0.45 kg CO$_2$e/kWh"),
    ("edge_pue", 1.05, 1.35, "Edge PUE", "1.05 to 1.35"),
    ("cloud_pue", 1.10, 1.45, "Hosted PUE", "1.10 to 1.45"),
    (
        "mid_network_wh",
        0.0002,
        0.0020,
        "Mid-sized hosted network energy",
        "0.0002 to 0.0020 Wh/request",
    ),
    (
        "large_network_wh",
        0.0005,
        0.0040,
        "Large hosted network energy",
        "0.0005 to 0.0040 Wh/request",
    ),
    ("volume_multiplier", 0.80, 1.20, "Arrival-volume multiplier", "0.80 to 1.20"),
    ("ability_shift", -0.05, 0.05, "Tier-ability shift", "$-0.05$ to 0.05"),
    (
        "prediction_noise",
        0.04,
        0.13,
        "Router prediction-error standard deviation",
        "0.04 to 0.13",
    ),
    ("edge_idle_fraction", 0.05, 0.30, "Edge idle allocation", "0.05 to 0.30"),
    (
        "edge_embodied_kg",
        120.0,
        360.0,
        "Edge embodied emissions",
        "120 to 360 kg CO$_2$e",
    ),
    ("edge_life_years", 3.0, 6.0, "Edge hardware life", "3 to 6 years"),
)


def sigmoid(value: float) -> float:
    return 1.0 / (1.0 + math.exp(-max(-40.0, min(40.0, value))))


def arrival_profile(bin_minutes: int, scenario: str) -> np.ndarray:
    bins = int(24 * 60 / bin_minutes)
    hours = np.arange(bins) * bin_minutes / 60.0
    profile = (
        0.20
        + 0.75 * np.exp(-0.5 * ((hours - 11.0) / 2.5) ** 2)
        + 1.00 * np.exp(-0.5 * ((hours - 17.0) / 2.8) ** 2)
    )
    if scenario == "festival_surge":
        profile += 1.4 * np.exp(-0.5 * ((hours - 19.0) / 1.7) ** 2)
    elif scenario == "safety_disruption":
        profile += 1.8 * np.exp(-0.5 * ((hours - 18.0) / 1.1) ** 2)
    return profile / profile.sum()


def generate_arrivals(
    rng: np.random.Generator,
    scenario_name: str,
    bin_minutes: int,
    volume_multiplier: float,
) -> list[list[dict[str, Any]]]:
    config = SCENARIOS[scenario_name]
    if not math.isclose(sum(config["complexity"]), 1.0, abs_tol=1e-12):
        raise AssertionError(
            f"Complexity probabilities do not sum to one for {scenario_name}"
        )
    profile = arrival_profile(bin_minutes, scenario_name)
    expected = float(config["daily_volume"]) * volume_multiplier * profile
    bin_counts = rng.poisson(expected)
    bins: list[list[dict[str, Any]]] = []
    for bin_index, total in enumerate(bin_counts):
        hour = bin_index * bin_minutes / 60.0
        complexity_counts = rng.multinomial(int(total), config["complexity"])
        categories: list[dict[str, Any]] = []
        for complexity, class_count in zip(COMPLEXITIES, complexity_counts):
            if class_count == 0:
                continue
            safety_probability = float(config["safety_base"])
            start_end = config["surge_hours"]
            if (
                scenario_name == "safety_disruption"
                and start_end
                and start_end[0] <= hour < start_end[1]
            ):
                safety_probability = 0.18 if complexity == "complex" else 0.04
            safety_count = int(rng.binomial(class_count, safety_probability))
            regular_count = int(class_count - safety_count)
            diff_counts = rng.multinomial(regular_count, DIFFICULTY_WEIGHTS)
            for difficulty_index, (difficulty, difficulty_count) in enumerate(
                zip(DIFFICULTY_POINTS[complexity], diff_counts)
            ):
                prediction_counts = rng.multinomial(
                    int(difficulty_count), PREDICTION_Z_WEIGHTS
                )
                for prediction_z, count in zip(
                    PREDICTION_Z_POINTS, prediction_counts
                ):
                    if count:
                        categories.append(
                            {
                                "count": int(count),
                                "complexity": complexity,
                                "difficulty": float(difficulty),
                                "input_token_factor": INPUT_TOKEN_FACTORS[
                                    difficulty_index
                                ],
                                "output_token_factor": OUTPUT_TOKEN_FACTORS[
                                    difficulty_index
                                ],
                                "prediction_z": float(prediction_z),
                                "arrival_fraction": float(rng.random()),
                                "safety": False,
                            }
                        )
            if safety_count:
                categories.append(
                    {
                        "count": safety_count,
                        "complexity": complexity,
                        "difficulty": 0.95,
                        "input_token_factor": 1.25,
                        "output_token_factor": 1.35,
                        "prediction_z": 0.0,
                        "arrival_fraction": float(rng.random()),
                        "safety": True,
                    }
                )
        bins.append(sorted(categories, key=lambda item: item["arrival_fraction"]))
    return bins


def parameter_draws(draws: int, seed: int) -> pd.DataFrame:
    sampler = qmc.LatinHypercube(d=len(PARAMETER_SPECS) + 3, seed=seed)
    unit = sampler.random(draws)
    values = np.empty((draws, len(PARAMETER_SPECS)))
    for column, (_, low, high, _, _) in enumerate(PARAMETER_SPECS):
        values[:, column] = low + unit[:, column] * (high - low)
    columns = [spec[0] for spec in PARAMETER_SPECS]
    frame = pd.DataFrame(values, columns=columns)
    for tier_index, tier in enumerate(TIER_ORDER):
        base = BASE_WORKERS[tier]
        frame[f"{tier}_workers"] = np.maximum(
            1,
            np.round(
                base
                * (
                    0.75
                    + 0.5
                    * unit[:, len(PARAMETER_SPECS) + tier_index]
                )
            ).astype(int),
        )
    frame.insert(0, "draw", np.arange(draws))
    return frame


def load_calibration(path: Path) -> dict[str, Any]:
    calibration = json.loads(path.read_text(encoding="utf-8"))
    for tier in TIER_ORDER:
        for complexity in COMPLEXITIES:
            calibration["tiers"][tier][complexity]
    return calibration


def sampled_calibration(
    calibration: dict[str, Any],
    params: pd.Series,
) -> dict[str, dict[str, dict[str, float]]]:
    sampled: dict[str, dict[str, dict[str, float]]] = {}
    for tier in TIER_ORDER:
        sampled[tier] = {}
        for complexity in COMPLEXITIES:
            base = calibration["tiers"][tier][complexity]
            prompt_tokens = float(base.get("mean_prompt_tokens", 0.0))
            output_tokens = float(base["mean_output_tokens"])
            energy_model = calibration.get("fitted_models", {}).get(
                tier, {}
            ).get("dynamic_energy_wh")
            latency_model = calibration.get("fitted_models", {}).get(
                tier, {}
            ).get("wall_seconds")
            if energy_model:
                coefficients = energy_model["coefficients"]
                base_energy = (
                    coefficients[0]
                    + coefficients[1] * prompt_tokens
                    + coefficients[2] * output_tokens
                )
            else:
                base_energy = float(base["energy_wh_mean"])
            if latency_model:
                coefficients = latency_model["coefficients"]
                base_latency = (
                    coefficients[0]
                    + coefficients[1] * prompt_tokens
                    + coefficients[2] * output_tokens
                )
            else:
                base_latency = float(base["latency_s_mean"])
            sampled[tier][complexity] = {
                "energy_wh": max(
                    1e-8,
                    base_energy * float(params.energy_multiplier),
                ),
                "latency_s": max(
                    0.01,
                    base_latency * float(params.latency_multiplier),
                ),
                "mean_prompt_tokens": prompt_tokens,
                "mean_output_tokens": output_tokens,
                "energy_coefficients": energy_model["coefficients"]
                if energy_model
                else None,
                "latency_coefficients": latency_model["coefficients"]
                if latency_model
                else None,
                "energy_multiplier": float(params.energy_multiplier),
                "latency_multiplier": float(params.latency_multiplier),
            }
    return sampled


def request_measurements(
    tier: str,
    complexity: str,
    sampled: dict[str, dict[str, dict[str, float]]],
    input_token_factor: float,
    output_token_factor: float,
) -> tuple[float, float]:
    profile = sampled[tier][complexity]
    prompt_tokens = profile.get("mean_prompt_tokens", 1.0) * input_token_factor
    output_tokens = profile.get("mean_output_tokens", 1.0) * output_token_factor
    energy_coefficients = profile.get("energy_coefficients")
    latency_coefficients = profile.get("latency_coefficients")
    if energy_coefficients:
        energy_wh = (
            energy_coefficients[0]
            + energy_coefficients[1] * prompt_tokens
            + energy_coefficients[2] * output_tokens
        ) * profile["energy_multiplier"]
    else:
        energy_wh = profile["energy_wh"] * (
            0.35 + 0.25 * input_token_factor + 0.40 * output_token_factor
        )
    if latency_coefficients:
        latency_s = (
            latency_coefficients[0]
            + latency_coefficients[1] * prompt_tokens
            + latency_coefficients[2] * output_tokens
        ) * profile["latency_multiplier"]
    else:
        latency_s = profile["latency_s"] * (
            0.25 + 0.20 * input_token_factor + 0.55 * output_token_factor
        )
    return max(energy_wh, 1e-8), max(latency_s, 0.01)


def tier_carbon_g(
    tier: str,
    complexity: str,
    sampled: dict[str, dict[str, dict[str, float]]],
    params: pd.Series,
    edge_ci: float,
    cloud_ci: float,
    input_token_factor: float,
    output_token_factor: float,
) -> float:
    energy_wh, _ = request_measurements(
        tier,
        complexity,
        sampled,
        input_token_factor,
        output_token_factor,
    )
    energy_kwh = energy_wh / 1000.0
    if tier == "compact":
        return energy_kwh * float(params.edge_pue) * edge_ci * 1000.0
    network_wh = (
        float(params.mid_network_wh)
        if tier == "mid"
        else float(params.large_network_wh)
    )
    return (
        (
            energy_kwh * float(params.cloud_pue)
            + network_wh / 1000.0
        )
        * cloud_ci
        * 1000.0
    )


# ---------------------------------------------------------------------------
# Alternative service-adequacy functional forms (reviewer R3-M2).
#
# Every form maps the ability margin u = a_m + delta_a - d to an adequacy
# probability. All forms share two properties so that the comparison isolates
# functional shape rather than a relabelled threshold:
#   (i)  p(0) = 0.5, so the crossing point where tier ability matches predicted
#        difficulty is identical across forms;
#   (ii) p is non-decreasing in u.
# The forms then differ in threshold sharpness (local slope at u = 0) and in
# curvature and tail behaviour away from the crossing point.
#
#   logistic8            baseline used in the main analysis, slope 8,
#                        derivative 2.0 at u = 0, smooth and symmetric.
#   logistic3            same logistic family, slope 3, derivative 0.75 at
#                        u = 0: a materially softer feasibility transition.
#   piecewise_linear     local slope matched to the baseline (derivative 2.0)
#                        but non-smooth, with hard saturation at |u| = 0.25.
#   laplace_exponential  local slope matched to the baseline (derivative 2.0)
#                        but sharply concave above and convex below the
#                        crossing point, with exponential rather than logistic
#                        tails.
# ---------------------------------------------------------------------------


def _adequacy_logistic8(margin: float) -> float:
    return sigmoid(margin * 8.0)


def _adequacy_logistic3(margin: float) -> float:
    return sigmoid(margin * 3.0)


def _adequacy_piecewise_linear(margin: float) -> float:
    return min(1.0, max(0.0, 0.5 + 2.0 * margin))


def _adequacy_laplace_exponential(margin: float) -> float:
    scaled = max(-40.0, min(40.0, 4.0 * margin))
    if margin >= 0.0:
        return 1.0 - 0.5 * math.exp(-scaled)
    return 0.5 * math.exp(scaled)


ADEQUACY_FORMS = {
    "logistic8": _adequacy_logistic8,
    "logistic3": _adequacy_logistic3,
    "piecewise_linear": _adequacy_piecewise_linear,
    "laplace_exponential": _adequacy_laplace_exponential,
}
ADEQUACY_FORM_LABELS = {
    "logistic8": "Logistic 8 (base)",
    "logistic3": "Logistic 3",
    "piecewise_linear": "Piecewise",
    "laplace_exponential": "Exponential",
}
BASELINE_ADEQUACY_FORM = "logistic8"
ADEQUACY_FORM = BASELINE_ADEQUACY_FORM


def set_adequacy_form(name: str) -> None:
    """Select the adequacy functional form used by adequacy_probability."""
    if name not in ADEQUACY_FORMS:
        raise ValueError(f"unknown adequacy form: {name}")
    global ADEQUACY_FORM
    ADEQUACY_FORM = name


def adequacy_probability(
    tier: str, difficulty: float, ability_shift: float
) -> float:
    margin = BASE_ABILITY[tier] + ability_shift - difficulty
    return ADEQUACY_FORMS[ADEQUACY_FORM](margin)


def route_request(
    strategy: str,
    complexity: str,
    difficulty: float,
    predicted_difficulty: float,
    safety: bool,
    backlogs: dict[str, float],
    sampled: dict[str, dict[str, dict[str, float]]],
    params: pd.Series,
    edge_ci: float,
    cloud_ci: float,
    input_token_factor: float,
    output_token_factor: float,
) -> tuple[str, list[str], bool]:
    if safety:
        return "large", ["large"], False
    if strategy == "large_only":
        return "large", ["large"], False
    if strategy == "mid_default":
        tier = "mid"
        _, service = request_measurements(
            tier,
            complexity,
            sampled,
            input_token_factor,
            output_token_factor,
        )
        projected = (
            backlogs[tier] / int(params[f"{tier}_workers"])
            + service
        )
        if projected > SLA_SECONDS[complexity] * 2.0:
            return "large", ["large"], True
        return tier, [tier], False
    if strategy == "fixed_threshold":
        tier = {"simple": "compact", "moderate": "mid", "complex": "large"}[
            complexity
        ]
        _, service = request_measurements(
            tier,
            complexity,
            sampled,
            input_token_factor,
            output_token_factor,
        )
        projected = (
            backlogs[tier] / int(params[f"{tier}_workers"])
            + service
        )
        if tier != "large" and projected > SLA_SECONDS[complexity] * 2.0:
            return "large", ["large"], True
        return tier, [tier], False
    if strategy == "quality_cascade":
        attempts: list[str] = []
        for tier in TIER_ORDER:
            attempts.append(tier)
            probability = adequacy_probability(
                tier, predicted_difficulty, float(params.ability_shift)
            )
            if probability >= QUALITY_TARGET[complexity] or tier == "large":
                return tier, attempts, False
    candidates: list[tuple[float, str]] = []
    use_difficulty = difficulty if strategy == "oracle" else predicted_difficulty
    for tier in TIER_ORDER:
        probability = adequacy_probability(
            tier, use_difficulty, float(params.ability_shift)
        )
        workers = int(params[f"{tier}_workers"])
        _, service = request_measurements(
            tier,
            complexity,
            sampled,
            input_token_factor,
            output_token_factor,
        )
        estimated_wait = backlogs[tier] / workers
        completion = estimated_wait + service
        if probability < QUALITY_TARGET[complexity]:
            continue
        if completion > SLA_SECONDS[complexity]:
            continue
        carbon = tier_carbon_g(
            tier,
            complexity,
            sampled,
            params,
            edge_ci,
            cloud_ci,
            input_token_factor,
            output_token_factor,
        )
        candidates.append((carbon, tier))
    if not candidates:
        return "large", ["large"], True
    _, tier = min(candidates)
    return tier, [tier], False


def simulate_day(
    arrivals: list[list[dict[str, Any]]],
    strategy: str,
    sampled: dict[str, dict[str, dict[str, float]]],
    params: pd.Series,
    bin_minutes: int,
    idle_power_w: float,
) -> dict[str, float]:
    bin_seconds = bin_minutes * 60.0
    backlogs = {tier: 0.0 for tier in TIER_ORDER}
    service_work_added = {tier: 0.0 for tier in TIER_ORDER}
    service_work_drained = {tier: 0.0 for tier in TIER_ORDER}
    max_queue_seconds = {tier: 0.0 for tier in TIER_ORDER}
    waits: list[tuple[float, float]] = []
    total_queries = 0
    safety_queries = 0
    safety_to_large = 0
    adequate = 0
    sla_met = 0
    timed_out = 0
    failed_over = 0
    operational_carbon_g = 0.0
    total_dynamic_wh = 0.0
    carbon_reversal_queries = 0
    routed_counts = {tier: 0 for tier in TIER_ORDER}
    attempt_counts = {tier: 0 for tier in TIER_ORDER}
    edge_ci_base = float(params.edge_ci)
    cloud_ci_base = float(params.cloud_ci)

    for bin_index, categories in enumerate(arrivals):
        previous_fraction = 0.0
        for category in categories:
            arrival_fraction = float(category["arrival_fraction"])
            elapsed = (arrival_fraction - previous_fraction) * bin_seconds
            for tier in TIER_ORDER:
                capacity = elapsed * int(params[f"{tier}_workers"])
                drained = min(backlogs[tier], capacity)
                backlogs[tier] -= drained
                service_work_drained[tier] += drained
            previous_fraction = arrival_fraction
            hour = (
                bin_index * bin_minutes
                + arrival_fraction * bin_minutes
            ) / 60.0
            edge_ci = max(
                0.01,
                edge_ci_base
                * (
                    1.0
                    + 0.25
                    * math.sin((hour - 14) / 24 * 2 * math.pi)
                ),
            )
            cloud_ci = max(
                0.01,
                cloud_ci_base
                * (
                    1.0
                    + 0.18
                    * math.sin((hour - 18) / 24 * 2 * math.pi)
                ),
            )
            count = int(category["count"])
            complexity = str(category["complexity"])
            difficulty = float(category["difficulty"])
            input_token_factor = float(category["input_token_factor"])
            output_token_factor = float(category["output_token_factor"])
            safety = bool(category["safety"])
            predicted = float(
                np.clip(
                    difficulty
                    + float(category["prediction_z"])
                    * float(params.prediction_noise),
                    0.0,
                    1.0,
                )
            )
            tier, attempts, failover = route_request(
                strategy,
                complexity,
                difficulty,
                predicted,
                safety,
                backlogs,
                sampled,
                params,
                edge_ci,
                cloud_ci,
                input_token_factor,
                output_token_factor,
            )
            if strategy == "green_route" and not safety and tier != "compact":
                compact_probability = adequacy_probability(
                    "compact",
                    predicted,
                    float(params.ability_shift),
                )
                compact_completion = (
                    backlogs["compact"] / int(params["compact_workers"])
                    + request_measurements(
                        "compact",
                        complexity,
                        sampled,
                        input_token_factor,
                        output_token_factor,
                    )[1]
                )
                compact_feasible = (
                    compact_probability >= QUALITY_TARGET[complexity]
                    and compact_completion <= SLA_SECONDS[complexity]
                )
                if compact_feasible:
                    compact_carbon = tier_carbon_g(
                        "compact",
                        complexity,
                        sampled,
                        params,
                        edge_ci,
                        cloud_ci,
                        input_token_factor,
                        output_token_factor,
                    )
                    selected_carbon = tier_carbon_g(
                        tier,
                        complexity,
                        sampled,
                        params,
                        edge_ci,
                        cloud_ci,
                        input_token_factor,
                        output_token_factor,
                    )
                    if selected_carbon < compact_carbon:
                        carbon_reversal_queries += count
            base_completion = 0.0
            completion_slope = 0.0
            final_wait_start = 0.0
            final_wait_slope = 0.0
            for attempted_tier in attempts:
                workers = int(params[f"{attempted_tier}_workers"])
                wait = backlogs[attempted_tier] / workers
                _, service = request_measurements(
                    attempted_tier,
                    complexity,
                    sampled,
                    input_token_factor,
                    output_token_factor,
                )
                base_completion += wait + service
                completion_slope += service / workers
                if attempted_tier == tier:
                    final_wait_start = wait
                    final_wait_slope = service / workers
                backlogs[attempted_tier] += service * count
                service_work_added[attempted_tier] += service * count
                max_queue_seconds[attempted_tier] = max(
                    max_queue_seconds[attempted_tier],
                    backlogs[attempted_tier] / workers,
                )
            timeout_limit = SLA_SECONDS[complexity] * 2.0

            total_queries += count
            routed_counts[tier] += count
            failed_over += count if failover else 0
            if safety:
                safety_queries += count
                if tier == "large":
                    safety_to_large += count
            for quantile_index in range(10):
                within_group_rank = (quantile_index + 0.5) / 10.0
                waits.append(
                    (
                        final_wait_start
                        + final_wait_slope
                        * max(0.0, within_group_rank * count - 1.0),
                        count / 10.0,
                    )
                )
            sla_met += count_completing_within(
                base_completion,
                completion_slope,
                count,
                SLA_SECONDS[complexity],
            )
            timed_out += count - count_completing_within(
                base_completion,
                completion_slope,
                count,
                timeout_limit,
            )

            probability = adequacy_probability(
                tier, difficulty, float(params.ability_shift)
            )
            adequate += count * probability
            for attempted_tier in attempts:
                attempt_counts[attempted_tier] += count
                energy_wh, _ = request_measurements(
                    attempted_tier,
                    complexity,
                    sampled,
                    input_token_factor,
                    output_token_factor,
                )
                energy_wh *= count
                total_dynamic_wh += energy_wh
                operational_carbon_g += tier_carbon_g(
                    attempted_tier,
                    complexity,
                    sampled,
                    params,
                    edge_ci,
                    cloud_ci,
                    input_token_factor,
                    output_token_factor,
                ) * count
        remaining = (1.0 - previous_fraction) * bin_seconds
        for tier in TIER_ORDER:
            capacity = remaining * int(params[f"{tier}_workers"])
            drained = min(backlogs[tier], capacity)
            backlogs[tier] -= drained
            service_work_drained[tier] += drained

    for tier in TIER_ORDER:
        conservation_error = (
            service_work_added[tier]
            - service_work_drained[tier]
            - backlogs[tier]
        )
        if not math.isclose(conservation_error, 0.0, abs_tol=1e-6):
            raise AssertionError(
                f"Queue conservation failed for {tier}: {conservation_error}"
            )

    edge_deployed = strategy in {
        "fixed_threshold",
        "quality_cascade",
        "green_route",
        "oracle",
    }
    edge_idle_wh = (
        idle_power_w
        * 24.0
        * float(params.edge_idle_fraction)
        if edge_deployed
        else 0.0
    )
    operational_carbon_g += (
        edge_idle_wh / 1000.0 * float(params.edge_pue) * edge_ci_base * 1000.0
    )
    total_energy_wh = total_dynamic_wh + edge_idle_wh

    p95_wait = weighted_count_quantile(waits, 0.95)
    embodied_daily_g = (
        float(params.edge_embodied_kg)
        * 1000.0
        / (float(params.edge_life_years) * 365.0)
        * float(params.edge_idle_fraction)
        if edge_deployed
        else 0.0
    )
    metrics = {
        "queries": total_queries,
        "operational_carbon_kg": operational_carbon_g / 1000.0,
        "extended_carbon_kg": (operational_carbon_g + embodied_daily_g) / 1000.0,
        "energy_kwh": total_energy_wh / 1000.0,
        "adequacy_rate": adequate / total_queries if total_queries else 1.0,
        "sla_rate": sla_met / total_queries if total_queries else 1.0,
        "timeout_rate": timed_out / total_queries if total_queries else 0.0,
        "failover_rate": failed_over / total_queries if total_queries else 0.0,
        "carbon_reversal_rate": carbon_reversal_queries / total_queries
        if total_queries
        else 0.0,
        "p95_wait_s": p95_wait,
        "max_queue_s": max(max_queue_seconds.values()),
        "unfinished_queue_work_s": sum(backlogs.values()),
        "safety_escalation_rate": safety_to_large / safety_queries
        if safety_queries
        else 1.0,
        "compact_share": routed_counts["compact"] / total_queries
        if total_queries
        else 0.0,
        "mid_share": routed_counts["mid"] / total_queries if total_queries else 0.0,
        "large_share": routed_counts["large"] / total_queries
        if total_queries
        else 0.0,
        "compact_attempts_per_query": attempt_counts["compact"] / total_queries
        if total_queries
        else 0.0,
        "mid_attempts_per_query": attempt_counts["mid"] / total_queries
        if total_queries
        else 0.0,
        "large_attempts_per_query": attempt_counts["large"] / total_queries
        if total_queries
        else 0.0,
    }
    for rate_name in (
        "adequacy_rate",
        "sla_rate",
        "timeout_rate",
        "failover_rate",
        "carbon_reversal_rate",
        "safety_escalation_rate",
        "compact_share",
        "mid_share",
        "large_share",
    ):
        if not 0.0 <= metrics[rate_name] <= 1.0:
            raise AssertionError(f"Invalid rate {rate_name}: {metrics[rate_name]}")
    if total_queries and not math.isclose(
        metrics["compact_share"]
        + metrics["mid_share"]
        + metrics["large_share"],
        1.0,
        abs_tol=1e-12,
    ):
        raise AssertionError("Routing shares do not sum to one")
    return metrics


def weighted_count_quantile(
    observations: list[tuple[float, float]], quantile: float
) -> float:
    if not observations:
        return 0.0
    ordered = sorted(observations, key=lambda item: item[0])
    total_weight = sum(weight for _, weight in ordered)
    target = quantile * total_weight
    cumulative = 0.0
    for value, weight in ordered:
        cumulative += weight
        if cumulative >= target:
            return float(value)
    return float(ordered[-1][0])


def count_completing_within(
    base_completion: float,
    completion_slope: float,
    count: int,
    limit: float,
) -> int:
    if count <= 0 or base_completion > limit:
        return 0
    if completion_slope <= 0:
        return count
    maximum_index = math.floor((limit - base_completion) / completion_slope)
    return max(0, min(count, maximum_index + 1))


def weighted_quantile(values: pd.Series, quantile: float) -> float:
    return float(values.quantile(quantile))


def summarise_simulation(results: pd.DataFrame) -> pd.DataFrame:
    metrics = [
        "operational_carbon_kg",
        "extended_carbon_kg",
        "adequacy_rate",
        "sla_rate",
        "timeout_rate",
        "failover_rate",
        "carbon_reversal_rate",
        "p95_wait_s",
        "max_queue_s",
        "unfinished_queue_work_s",
        "safety_escalation_rate",
        "compact_share",
        "mid_share",
        "large_share",
        "compact_attempts_per_query",
        "mid_attempts_per_query",
        "large_attempts_per_query",
    ]
    rows: list[dict[str, Any]] = []
    for (scenario, strategy), group in results.groupby(["scenario", "strategy"]):
        row: dict[str, Any] = {"scenario": scenario, "strategy": strategy}
        for metric in metrics:
            row[f"{metric}_median"] = weighted_quantile(group[metric], 0.50)
            row[f"{metric}_low"] = weighted_quantile(group[metric], 0.025)
            row[f"{metric}_high"] = weighted_quantile(group[metric], 0.975)
        rows.append(row)
    return pd.DataFrame(rows)


def break_even_analysis(
    results: pd.DataFrame, draws: pd.DataFrame
) -> pd.DataFrame:
    green = results[results.strategy == "green_route"]
    baseline = results[results.strategy == "large_only"]
    merged = green.merge(
        baseline,
        on=["scenario", "draw", "replication"],
        suffixes=("_green", "_baseline"),
    ).merge(draws[["draw", "edge_embodied_kg", "edge_life_years", "edge_idle_fraction"]], on="draw")
    saving_g_per_query = (
        (merged.operational_carbon_kg_baseline - merged.operational_carbon_kg_green)
        * 1000.0
        / merged.queries_green
    )
    embodied_daily_g = (
        merged.edge_embodied_kg
        * 1000.0
        / (merged.edge_life_years * 365.0)
        * merged.edge_idle_fraction
    )
    merged["break_even_queries_per_day"] = np.where(
        saving_g_per_query > 0, embodied_daily_g / saving_g_per_query, np.inf
    )
    return merged[
        ["scenario", "draw", "replication", "break_even_queries_per_day"]
    ]


def configure_figures() -> None:
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 10,
            "axes.labelsize": 10,
            "axes.titlesize": 10,
            "xtick.labelsize": 9,
            "ytick.labelsize": 9,
            "legend.fontsize": 8.5,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
            "savefig.bbox": "tight",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )


def save_figure(fig: plt.Figure, output_dir: Path, stem: str) -> None:
    figure_dir = output_dir / "figures"
    figure_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(figure_dir / f"{stem}.pdf")
    fig.savefig(figure_dir / f"{stem}.eps")
    fig.savefig(figure_dir / f"{stem}.png", dpi=600)
    plt.close(fig)


def figure_framework(output_dir: Path) -> None:
    """Draw the actual safety bypass, decision path and accounting feedback."""
    fig, ax = plt.subplots(figsize=(8.2, 5.6))
    ax.set_xlim(0, 14.4)
    ax.set_ylim(-0.2, 9.2)
    ax.axis("off")

    def box(x, y, w, h, label, colour):
        ax.add_patch(FancyBboxPatch(
            (x, y), w, h, boxstyle="round,pad=0.03",
            facecolor="white", edgecolor=colour, linewidth=1.3))
        ax.text(x + w / 2, y + h / 2, label,
                ha="center", va="center", fontsize=10)

    def route(points, colour="#444444", dashed=False):
        for first, last in zip(points[:-2], points[1:-1]):
            ax.plot([first[0], last[0]], [first[1], last[1]],
                    color=colour, lw=1.2, ls="--" if dashed else "-")
        ax.add_patch(FancyArrowPatch(
            points[-2], points[-1], arrowstyle="-|>",
            mutation_scale=12, color=colour, linewidth=1.2,
            linestyle="--" if dashed else "-"))

    box(.3, 6.8, 3.0, 1.2, "(1) Request intake\nClass, safety flag,\nservice targets", "#0072B2")
    box(.3, 3.9, 3.0, 1.2, "(2) Estimate difficulty\nRead current queues", "#0072B2")
    box(5.0, 3.6, 3.5, 1.7, "(3) Feasibility filters\nAdequacy, time, capacity\nthen lowest carbon", "#009E73")
    box(10.2, 6.4, 3.0, 1.2, "(6) Large hosted tier\nSafety, failover or\nfeasible assignment", "#CC79A7")
    box(10.2, 3.9, 3.0, 1.2, "(5) Mid-sized\nhosted tier", "#E69F00")
    box(10.2, 1.8, 3.0, 1.2, "(4) Compact\nedge tier", "#009E73")
    box(4.5, .0, 4.8, 1.1, "(7) Attempt accounting\nEnergy, carbon, queue, SLA,\nmodelled adequacy", "#555555")
    box(5.2, 6.8, 3.0, 1.0, "Carbon-intensity feed\nSynthetic trajectory", "#555555")

    route([(1.8, 8.0), (1.8, 8.6), (11.7, 8.6), (11.7, 7.6)], "#A23B72", True)
    ax.text(7.0, 8.83, "Safety flagged: bypass optimisation", ha="center", fontsize=9.5, color="#A23B72")
    route([(1.8, 6.8), (1.8, 5.1)])
    ax.text(1.95, 5.85, "Otherwise", ha="left", fontsize=9)
    route([(3.3, 4.5), (5.0, 4.5)])
    route([(6.7, 6.8), (6.7, 5.3)])
    route([(8.5, 4.9), (10.2, 7.0)])
    route([(8.5, 4.45), (10.2, 4.5)])
    route([(8.5, 4.0), (10.2, 2.4)])
    for y in (7.0, 4.5, 2.4):
        ax.plot([13.2, 13.9], [y, y], color="#555555", lw=1.2)
    route([(13.9, 7.0), (13.9, .55), (9.3, .55)])
    route([(4.5, .55), (1.8, .55), (1.8, 3.9)])
    ax.text(1.6, 2.3, "Updated\nqueue state", ha="right", fontsize=9)
    save_figure(fig, output_dir, "Fig1")


def figure_calibration(calibration: dict[str, Any], output_dir: Path) -> None:
    summary = pd.DataFrame(calibration["summary_rows"])
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.8))
    x = np.arange(len(COMPLEXITIES))
    width = 0.24
    tier_colours = {"compact": "#009E73", "mid": "#E69F00", "large": "#CC79A7"}
    tier_display = {"compact": "Edge", "mid": "Mid", "large": "Large"}
    for index, tier in enumerate(TIER_ORDER):
        subset = summary[summary.model_tier == tier].set_index("complexity").loc[list(COMPLEXITIES)]
        energy_bars = axes[0].bar(
            x + (index - 1) * width,
            subset.energy_wh_mean,
            width,
            yerr=np.vstack(
                (
                    subset.energy_wh_mean - subset.energy_ci_low,
                    subset.energy_ci_high - subset.energy_wh_mean,
                )
            ),
            capsize=2,
            label=tier_display[tier],
            color=tier_colours[tier],
            edgecolor="black",
        )
        latency_bars = axes[1].bar(
            x + (index - 1) * width,
            subset.latency_s_mean,
            width,
            yerr=np.vstack(
                (
                    subset.latency_s_mean - subset.latency_ci_low,
                    subset.latency_ci_high - subset.latency_s_mean,
                )
            ),
            capsize=2,
            label=tier_display[tier],
            color=tier_colours[tier],
            edgecolor="black",
        )
        for bar in (*energy_bars, *latency_bars):
            bar.set_hatch(("/", "\\\\", "xx")[index])
    for panel_index, (ax, ylabel) in enumerate(
        zip(axes, ("Dynamic energy (Wh/query)", "Wall-clock latency (s/query)"))
    ):
        ax.set_title(
            f"({chr(97 + panel_index)}) "
            + ("Measured energy" if panel_index == 0 else "Measured latency"),
            loc="left",
            fontweight="bold",
            fontsize=9.5,
            pad=4,
        )
        ax.set_xticks(x, [item.title() for item in COMPLEXITIES])
        ax.set_xlabel("Prompt complexity class")
        ax.set_ylabel(ylabel)
        ax.grid(axis="y", color="#dddddd", linewidth=0.5)
    axes[0].legend(frameon=False, title="Model tier")
    save_figure(fig, output_dir, "Fig2")


def figure_strategy_outcomes(summary: pd.DataFrame, output_dir: Path) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 6.8))
    scenarios = list(SCENARIOS)
    strategies = list(STRATEGIES)
    x = np.arange(len(strategies))
    short_labels = ["Large", "Mid", "Fixed", "Cascade", "Green", "Oracle"]
    for panel_index, (carbon_ax, scenario) in enumerate(
        zip(axes.flat, scenarios)
    ):
        subset = summary[summary.scenario == scenario].set_index("strategy").loc[strategies]
        med = subset.operational_carbon_kg_median.to_numpy()
        low = subset.operational_carbon_kg_low.to_numpy()
        high = subset.operational_carbon_kg_high.to_numpy()
        carbon_bars = carbon_ax.bar(
            x,
            med,
            yerr=np.vstack((med - low, high - med)),
            capsize=2,
            color=[COLOURS[item] for item in strategies],
            edgecolor="black",
        )
        adequacy_med = subset.adequacy_rate_median.to_numpy() * 100.0
        adequacy_low = subset.adequacy_rate_low.to_numpy() * 100.0
        adequacy_high = subset.adequacy_rate_high.to_numpy() * 100.0
        adequacy_ax = carbon_ax.twinx()
        adequacy_ax.errorbar(
            x,
            adequacy_med,
            yerr=np.vstack(
                (
                    adequacy_med - adequacy_low,
                    adequacy_high - adequacy_med,
                )
            ),
            color="black",
            marker="o",
            markersize=3.5,
            linewidth=1.0,
            capsize=2,
        )
        for bar, strategy in zip(carbon_bars, strategies):
            bar.set_hatch(HATCHES[strategy])
        carbon_ax.set_title(
            f"({chr(97 + panel_index)}) {SCENARIOS[scenario]['label']}",
            loc="left",
            fontweight="bold",
            fontsize=11,
            pad=4,
        )
        adequacy_ax.set_ylim(0, 100)
        carbon_ax.set_xticks(x, short_labels, rotation=50, ha="right")
        # R2-2: label both axes on every panel. Previously the carbon label
        # appeared only on the left column and the adequacy label only on the
        # right, so a reader of one panel could not decode its own axes.
        carbon_ax.set_ylabel("Operational carbon\n(kg CO$_2$e/day)", fontsize=11)
        adequacy_ax.set_ylabel("Modelled service\nadequacy (%)", fontsize=11)
        adequacy_ax.tick_params(axis="y", colors="#444444", labelsize=10)
        carbon_ax.tick_params(axis="both", labelsize=10)
        adequacy_ax.yaxis.label.set_color("#444444")
        carbon_ax.grid(axis="y", color="#dddddd", linewidth=0.5)
    legend_handles = [
        plt.Rectangle(
            (0, 0),
            1,
            1,
            facecolor=COLOURS[strategy],
            edgecolor="black",
            hatch=HATCHES[strategy],
            label=STRATEGY_LABELS[strategy],
        )
        for strategy in strategies
    ]
    legend_handles.append(
        plt.Line2D(
            [],
            [],
            color="black",
            marker="o",
            markersize=3.5,
            linewidth=1.0,
            label="Modelled service adequacy (right axis)",
        )
    )
    fig.legend(
        handles=legend_handles,
        loc="lower center",
        ncol=2,
        fontsize=10,
        frameon=False,
        bbox_to_anchor=(0.5, 0.0),
    )
    fig.subplots_adjust(wspace=1.05, hspace=0.48, bottom=0.22, top=0.95)
    save_figure(fig, output_dir, "Fig3")


def figure_queue_sla(summary: pd.DataFrame, output_dir: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 4.0))
    scenario = "peak_season"
    subset = summary[summary.scenario == scenario].set_index("strategy").loc[list(STRATEGIES)]
    x = np.arange(len(STRATEGIES))
    wait_bars = axes[0].bar(
        x,
        subset.p95_wait_s_median,
        color=[COLOURS[item] for item in STRATEGIES],
        edgecolor="black",
    )
    sla_bars = axes[1].bar(
        x,
        subset.sla_rate_median * 100.0,
        color=[COLOURS[item] for item in STRATEGIES],
        edgecolor="black",
    )
    for bars in (wait_bars, sla_bars):
        for bar, strategy in zip(bars, STRATEGIES):
            bar.set_hatch(HATCHES[strategy])
    labels = [STRATEGY_LABELS[item] for item in STRATEGIES]
    axes[0].set_ylabel("Median p95 queue wait (s)")
    axes[1].set_ylabel("Requests meeting\nresponse-time target (%)")
    axes[1].set_ylim(0, 100)
    for panel_index, ax in enumerate(axes):
        ax.set_title(
            f"({chr(97 + panel_index)}) "
            + ("Queue wait" if panel_index == 0 else "Response-time compliance"),
            loc="left",
            fontweight="bold",
            fontsize=9.5,
            pad=4,
        )
        ax.set_xticks(x, labels, rotation=55, ha="right")
        ax.grid(axis="y", color="#dddddd", linewidth=0.5)
    fig.subplots_adjust(wspace=0.42)
    save_figure(fig, output_dir, "Fig4")


def figure_pareto(summary: pd.DataFrame, output_dir: Path) -> None:
    fig, ax = plt.subplots(figsize=(5.6, 4.0))
    subset = summary[summary.scenario == "peak_season"]
    for _, row in subset.iterrows():
        strategy = row.strategy
        ax.scatter(
            row.operational_carbon_kg_median,
            row.adequacy_rate_median,
            color=COLOURS[strategy],
            edgecolor="black",
            s=55,
            marker=MARKERS[strategy],
            label=STRATEGY_LABELS[strategy],
        )
    # R3-m5: the two axes do not have equivalent empirical status, and the
    # asymmetry must be visible in the figure itself rather than only in the
    # caption. The carbon axis rests on a measured energy base within the
    # declared system boundary; the adequacy axis is generated by Eq. (1).
    ax.set_xlabel(
        "Operational carbon (kg CO$_2$e/day)\n"
        "measurement-calibrated, within the defined system boundary"
    )
    ax.set_ylabel(
        "MODELLED service adequacy\n"
        "generated by Eq. (1); not measured"
    )
    ax.grid(color="#dddddd", linewidth=0.5)
    ax.legend(
        frameon=True,
        facecolor="white",
        framealpha=1.0,
        edgecolor="none",
        loc="best",
    )
    save_figure(fig, output_dir, "Fig5")


def figure_uncertainty(
    results: pd.DataFrame, break_even: pd.DataFrame, output_dir: Path
) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 4.0))
    green = results[results.strategy == "green_route"]
    baseline = results[results.strategy == "large_only"]
    merged = green.merge(
        baseline,
        on=["scenario", "draw", "replication"],
        suffixes=("_green", "_baseline"),
    )
    merged["saving_percent"] = (
        (
            merged.operational_carbon_kg_baseline
            - merged.operational_carbon_kg_green
        )
        / merged.operational_carbon_kg_baseline
        * 100.0
    )
    data = [
        merged[merged.scenario == scenario].saving_percent.to_numpy()
        for scenario in SCENARIOS
    ]
    axes[0].boxplot(data, tick_labels=[SCENARIOS[item]["label"] for item in SCENARIOS], showfliers=False)
    axes[0].set_ylabel(
        "Green-Route operational carbon reduction\nrelative to large-only (%)"
    )
    axes[0].axhline(0.0, color="#888888", linewidth=0.8, linestyle="--")
    axes[0].tick_params(axis="x", rotation=35)
    be_data = [
        break_even[break_even.scenario == scenario]
        .break_even_queries_per_day.replace([np.inf], np.nan)
        .dropna()
        .to_numpy()
        for scenario in SCENARIOS
    ]
    axes[1].boxplot(be_data, tick_labels=[SCENARIOS[item]["label"] for item in SCENARIOS], showfliers=False)
    axes[1].set_yscale("log")
    axes[1].set_ylabel("Embodied-carbon break-even\n(requests/day, log scale)")
    axes[1].tick_params(axis="x", rotation=35)
    for panel_index, ax in enumerate(axes):
        ax.set_title(
            f"({chr(97 + panel_index)}) "
            + (
                "Carbon reduction vs large-only"
                if panel_index == 0
                else "Embodied-carbon break-even"
            ),
            loc="left",
            fontweight="bold",
            fontsize=9.5,
            pad=4,
        )
        ax.grid(axis="y", color="#dddddd", linewidth=0.5)
    fig.subplots_adjust(wspace=0.42)
    save_figure(fig, output_dir, "Fig6")


def latex_macro_name(*parts: str) -> str:
    return "".join(
        word.capitalize()
        for part in parts
        for word in part.replace("-", "_").split("_")
    )


def write_manuscript_assets(
    calibration: dict[str, Any],
    results: pd.DataFrame,
    summary: pd.DataFrame,
    break_even: pd.DataFrame,
    output_dir: Path,
) -> None:
    table_dir = output_dir / "tables"
    table_dir.mkdir(parents=True, exist_ok=True)
    calibration_summary = pd.DataFrame(calibration["summary_rows"])
    calibration_summary.to_csv(table_dir / "calibration_table.csv", index=False)

    green = results[results.strategy == "green_route"]
    baseline = results[results.strategy == "large_only"]
    paired = green.merge(
        baseline,
        on=["scenario", "draw", "replication"],
        suffixes=("_green", "_baseline"),
    )
    paired["carbon_reduction_percent"] = (
        (
            paired.operational_carbon_kg_baseline
            - paired.operational_carbon_kg_green
        )
        / paired.operational_carbon_kg_baseline
        * 100.0
    )
    paired_summary = (
        paired.groupby("scenario")["carbon_reduction_percent"]
        .quantile([0.025, 0.5, 0.975])
        .unstack()
        .rename(columns={0.025: "low", 0.5: "median", 0.975: "high"})
        .reset_index()
    )
    paired_summary.to_csv(
        table_dir / "paired_carbon_reductions.csv", index=False
    )
    summary.to_csv(table_dir / "strategy_results_table.csv", index=False)
    scenario_rows = []
    for scenario in SCENARIOS.values():
        simple, moderate, complex_value = scenario["complexity"]
        scenario_rows.append(
            f"{scenario['label']} & {scenario['daily_volume']:,} & "
            f"{100 * simple:.0f}\\% & {100 * moderate:.0f}\\% & "
            f"{100 * complex_value:.0f}\\%\\\\"
        )
    scenario_table = "\n".join(
        [
            r"\begin{table}[tbp]",
            r"\caption{Tourism demand scenarios. These are computational "
            r"stress conditions designed to span distinct load regimes, not "
            r"estimates of the traffic of any destination management "
            r"organisation; see Table~\ref{tab:provenance}}",
            r"\label{tab:scenarios}",
            r"\centering",
            r"\begin{tabular}{lrrrr}",
            r"\toprule",
            r"Scenario & Expected daily requests & Simple & Moderate & Complex\\",
            r"\midrule",
            *scenario_rows,
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{table}",
            "",
        ]
    )
    (table_dir / "scenario_table.tex").write_text(
        scenario_table, encoding="utf-8"
    )
    uncertainty_rows = [
        f"{label} & {display}\\\\"
        for _, _, _, label, display in PARAMETER_SPECS
    ]
    uncertainty_table = "\n".join(
        [
            r"\begin{table}[tbp]",
            r"\caption{Latin-hypercube uncertainty intervals. Worker "
            r"capacities are additionally varied from 75\% to 125\% of the "
            r"base pools of Table~\ref{tab:provenance}}",
            r"\label{tab:uncertainty}",
            r"\centering",
            r"\footnotesize",
            r"\begin{tabular}{p{4.2cm}p{3.2cm}}",
            r"\toprule",
            r"Parameter & Interval\\",
            r"\midrule",
            *uncertainty_rows,
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{table}",
            "",
        ]
    )
    (table_dir / "uncertainty_table.tex").write_text(
        uncertainty_table, encoding="utf-8"
    )

    green_table = summary[summary.strategy == "green_route"].set_index(
        "scenario"
    )
    large_table = summary[summary.strategy == "large_only"].set_index(
        "scenario"
    )
    reduction_table = paired_summary.set_index("scenario")
    result_rows = []
    for scenario_key, scenario in SCENARIOS.items():
        green_row = green_table.loc[scenario_key]
        large_row = large_table.loc[scenario_key]
        reduction_row = reduction_table.loc[scenario_key]
        result_rows.append(
            f"{scenario['label']} & "
            f"{large_row.operational_carbon_kg_median:.3f} & "
            f"{green_row.operational_carbon_kg_median:.3f} & "
            f"{reduction_row['median']:.1f}\\% & "
            f"{100.0 * green_row.adequacy_rate_median:.1f}\\% & "
            f"{100.0 * green_row.sla_rate_median:.1f}\\% & "
            f"{100.0 * green_row.timeout_rate_median:.1f}\\%\\\\"
        )
    main_results_table = "\n".join(
        [
            r"\begin{table}[tbp]",
            r"\caption{Headline Green-Route results across tourism demand "
            r"scenarios. Reduction is relative to large-model-only routing, "
            r"which measures the cost of not routing at all; "
            r"Table~\ref{tab:envelope} gives the comparison against the "
            r"stronger alternatives. Modelled adequacy is produced by "
            r"Eq.~\ref{eq:adequacy} and is not a measured response-quality "
            r"score}",
            r"\label{tab:headline_results}",
            r"\centering",
            r"\scriptsize",
            r"\setlength{\tabcolsep}{2pt}",
            r"\begin{tabular}{p{2.0cm}*{2}{>{\centering\arraybackslash}p{1.45cm}}>{\centering\arraybackslash}p{1.5cm}>{\centering\arraybackslash}p{1.35cm}>{\centering\arraybackslash}p{1.5cm}>{\centering\arraybackslash}p{1.3cm}}",
            r"\toprule",
            r"Scenario & Large-only carbon (kg/day) & Green-Route carbon "
            r"(kg/day) & Reduction vs large-only & Modelled service adequacy & "
            r"Response-time compliance & Timeout\\",
            r"\midrule",
            *result_rows,
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{table}",
            "",
        ]
    )
    (table_dir / "main_results_table.tex").write_text(
        main_results_table, encoding="utf-8"
    )

    macro_lines = [
        "% Automatically generated by green_route_study.py. Do not edit.",
        rf"\newcommand{{\BenchmarkPrompts}}{{{calibration.get('benchmark_protocol', {}).get('prompts', 30)}}}",
        rf"\newcommand{{\BenchmarkRepetitions}}{{{calibration.get('benchmark_protocol', {}).get('repetitions', 5)}}}",
        rf"\newcommand{{\SimulationDraws}}{{{results['draw'].nunique()}}}",
        rf"\newcommand{{\SimulationReplications}}{{{results['replication'].nunique()}}}",
        rf"\newcommand{{\SimulationRealisations}}{{{results['draw'].nunique() * results['replication'].nunique():,}}}",
    ]
    for tier in TIER_ORDER:
        for complexity in COMPLEXITIES:
            values = calibration["tiers"][tier][complexity]
            prefix = latex_macro_name(tier, complexity)
            macro_lines.extend(
                [
                    rf"\newcommand{{\{prefix}Energy}}{{{values['energy_wh_mean']:.5f}}}",
                    rf"\newcommand{{\{prefix}Latency}}{{{values['latency_s_mean']:.2f}}}",
                    rf"\newcommand{{\{prefix}Throughput}}{{{values['tokens_per_s_mean']:.1f}}}",
                ]
            )

    green_summary = green_table
    large_summary = large_table
    reduction_summary = reduction_table
    for scenario in SCENARIOS:
        prefix = latex_macro_name(scenario)
        row = green_summary.loc[scenario]
        large_row = large_summary.loc[scenario]
        reduction = reduction_summary.loc[scenario]
        break_even_values = (
            break_even[break_even.scenario == scenario]
            .break_even_queries_per_day.replace([np.inf], np.nan)
            .dropna()
        )
        break_even_median = (
            float(break_even_values.median())
            if not break_even_values.empty
            else math.nan
        )
        reversal_values = green[
            green.scenario == scenario
        ].carbon_reversal_rate
        positive_reversals = reversal_values[reversal_values > 0]
        reversal_case_rate = float((reversal_values > 0).mean() * 100.0)
        conditional_reversal = (
            float(positive_reversals.median() * 100.0)
            if not positive_reversals.empty
            else 0.0
        )
        macro_lines.extend(
            [
                rf"\newcommand{{\{prefix}Carbon}}{{{row.operational_carbon_kg_median:.3f}}}",
                rf"\newcommand{{\{prefix}CarbonLow}}{{{row.operational_carbon_kg_low:.3f}}}",
                rf"\newcommand{{\{prefix}CarbonHigh}}{{{row.operational_carbon_kg_high:.3f}}}",
                rf"\newcommand{{\{prefix}LargeCarbon}}{{{large_row.operational_carbon_kg_median:.3f}}}",
                rf"\newcommand{{\{prefix}Reduction}}{{{reduction['median']:.1f}\%}}",
                rf"\newcommand{{\{prefix}ReductionLow}}{{{reduction['low']:.1f}\%}}",
                rf"\newcommand{{\{prefix}ReductionHigh}}{{{reduction['high']:.1f}\%}}",
                rf"\newcommand{{\{prefix}Adequacy}}{{{100.0 * row.adequacy_rate_median:.1f}\%}}",
                rf"\newcommand{{\{prefix}SLA}}{{{100.0 * row.sla_rate_median:.1f}\%}}",
                rf"\newcommand{{\{prefix}Timeout}}{{{100.0 * row.timeout_rate_median:.1f}\%}}",
                rf"\newcommand{{\{prefix}Failover}}{{{100.0 * row.failover_rate_median:.1f}\%}}",
                rf"\newcommand{{\{prefix}PWait}}{{{row.p95_wait_s_median:.2f}}}",
                rf"\newcommand{{\{prefix}CompactShare}}{{{100.0 * row.compact_share_median:.1f}\%}}",
                rf"\newcommand{{\{prefix}MidShare}}{{{100.0 * row.mid_share_median:.1f}\%}}",
                rf"\newcommand{{\{prefix}LargeShare}}{{{100.0 * row.large_share_median:.1f}\%}}",
                rf"\newcommand{{\{prefix}CarbonReversal}}{{{100.0 * row.carbon_reversal_rate_median:.1f}\%}}",
                rf"\newcommand{{\{prefix}ReversalCases}}{{{reversal_case_rate:.1f}\%}}",
                rf"\newcommand{{\{prefix}ConditionalReversal}}{{{conditional_reversal:.1f}\%}}",
                rf"\newcommand{{\{prefix}BreakEven}}{{{break_even_median:,.0f}}}",
            ]
        )
    (output_dir / "manuscript_values.tex").write_text(
        "\n".join(macro_lines) + "\n", encoding="utf-8"
    )


def simulate_replication_task(
    task: tuple[
        dict[str, Any],
        dict[str, Any],
        int,
        int,
        int,
        float,
        int,
        str,
    ]
) -> list[dict[str, Any]]:
    (
        params_dict,
        calibration,
        replication,
        seed,
        bin_minutes,
        idle_power_w,
        scenario_seed_stride,
        adequacy_form,
    ) = task
    set_adequacy_form(adequacy_form)
    params = pd.Series(params_dict)
    sampled = sampled_calibration(calibration, params)
    rows: list[dict[str, Any]] = []
    for scenario_index, scenario in enumerate(SCENARIOS):
        stream_seed = (
            seed
            + int(params["draw"]) * 10_000
            + scenario_index * scenario_seed_stride
            + replication
        )
        arrivals = generate_arrivals(
            np.random.default_rng(stream_seed),
            scenario,
            bin_minutes,
            float(params["volume_multiplier"]),
        )
        for strategy in STRATEGIES:
            metrics = simulate_day(
                arrivals,
                strategy,
                sampled,
                params,
                bin_minutes,
                idle_power_w,
            )
            rows.append(
                {
                    "scenario": scenario,
                    "strategy": strategy,
                    "draw": int(params["draw"]),
                    "replication": replication,
                    **metrics,
                }
            )
    return rows


def run_simulation_rows(
    draws: pd.DataFrame,
    calibration: dict[str, Any],
    replications: int,
    seed: int,
    bin_minutes: int,
    idle_power_w: float,
    workers: int,
    adequacy_form: str = BASELINE_ADEQUACY_FORM,
    progress_label: str = "",
) -> pd.DataFrame:
    """Run every (draw, replication, scenario, strategy) cell and return rows.

    The adequacy functional form is passed explicitly into each worker task so
    that a sweep over forms cannot silently inherit the parent process state.
    """
    set_adequacy_form(adequacy_form)
    draw_count = int(draws.shape[0])
    rows: list[dict[str, Any]] = []
    tasks = [
        (
            params.to_dict(),
            calibration,
            replication,
            seed,
            bin_minutes,
            idle_power_w,
            1_000,
            adequacy_form,
        )
        for _, params in draws.iterrows()
        for replication in range(replications)
    ]
    if workers == 1:
        task_iterator = map(simulate_replication_task, tasks)
        executor_context = None
    else:
        executor_context = concurrent.futures.ProcessPoolExecutor(
            max_workers=workers,
            mp_context=multiprocessing.get_context("fork"),
        )
        task_iterator = executor_context.map(simulate_replication_task, tasks)
    try:
        for task_index, task_rows in enumerate(task_iterator, start=1):
            rows.extend(task_rows)
            if task_index % max(1, replications * 20) == 0:
                completed_draws = task_index // replications
                print(
                    f"{progress_label}Completed "
                    f"{completed_draws}/{draw_count} parameter draws"
                )
    finally:
        if executor_context is not None:
            executor_context.shutdown()
    return pd.DataFrame(rows)


def simulate(args: argparse.Namespace) -> None:
    calibration = load_calibration(args.calibration)
    output_dir: Path = args.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    draws = parameter_draws(args.draws, args.seed)
    draws.to_csv(output_dir / "parameter_draws.csv", index=False)
    idle_samples_path = args.calibration.parent / "idle_power_samples.csv"
    idle_power_w = (
        float(pd.read_csv(idle_samples_path)["total_w"].mean())
        if idle_samples_path.exists()
        else 1.0
    )
    bin_minutes = 15
    results = run_simulation_rows(
        draws=draws,
        calibration=calibration,
        replications=args.replications,
        seed=args.seed,
        bin_minutes=bin_minutes,
        idle_power_w=idle_power_w,
        workers=args.workers,
        adequacy_form=getattr(
            args, "adequacy_form", BASELINE_ADEQUACY_FORM
        ),
    )
    results.to_csv(output_dir / "simulation_results.csv", index=False)
    summary = summarise_simulation(results)
    summary.to_csv(output_dir / "simulation_summary.csv", index=False)
    break_even = break_even_analysis(results, draws)
    break_even.to_csv(output_dir / "break_even_analysis.csv", index=False)
    metadata = {
        "draws": args.draws,
        "replications": args.replications,
        "seed": args.seed,
        "workers": args.workers,
        "bin_minutes": bin_minutes,
        "scenarios": SCENARIOS,
        "strategies": STRATEGIES,
        "quality_source": "synthetic probabilistic service-adequacy model",
        "arrival_process": (
            "non-homogeneous Poisson arrivals represented as stratified grouped "
            "events within 15-minute intensity intervals"
        ),
        "pairing": (
            "identical parameter draws, grouped arrival events, latent "
            "difficulties and prediction-error strata across strategies"
        ),
        "operational_boundary": (
            "measured dynamic inference energy, PUE, network energy and "
            "allocated edge idle power"
        ),
        "extended_boundary": "operational boundary plus amortised edge hardware emissions",
        "calibration_file": str(args.calibration),
    }
    (output_dir / "simulation_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )
    write_manuscript_assets(
        calibration, results, summary, break_even, output_dir
    )
    configure_figures()
    figure_framework(output_dir)
    figure_calibration(calibration, output_dir)
    figure_strategy_outcomes(summary, output_dir)
    figure_queue_sla(summary, output_dir)
    figure_pareto(summary, output_dir)
    figure_uncertainty(results, break_even, output_dir)
    print(f"Simulation outputs written to {output_dir}")


DEPLOYABLE_STRATEGIES = (
    "large_only",
    "mid_default",
    "fixed_threshold",
    "quality_cascade",
    "green_route",
)


def envelope_comparison(summary: pd.DataFrame) -> pd.DataFrame:
    """Compare every strategy against the adequacy envelope Green-Route holds.

    Answers reviewer R3-M4: the headline comparison should not be against the
    weakest available baseline. For each scenario this records, for every
    strategy, whether it reaches at least Green-Route's median modelled service
    adequacy, and what it costs in operational carbon if it does.
    """
    rows: list[dict[str, Any]] = []
    for scenario in SCENARIOS:
        frame = summary[summary["scenario"] == scenario]
        green = frame[frame["strategy"] == "green_route"].iloc[0]
        floor = float(green["adequacy_rate_median"])
        green_carbon = float(green["operational_carbon_kg_median"])
        for _, row in frame.iterrows():
            adequacy = float(row["adequacy_rate_median"])
            carbon = float(row["operational_carbon_kg_median"])
            meets = adequacy >= floor
            rows.append(
                {
                    "scenario": scenario,
                    "strategy": row["strategy"],
                    "deployable": row["strategy"] in DEPLOYABLE_STRATEGIES,
                    "operational_carbon_kg": carbon,
                    "adequacy_rate": adequacy,
                    "sla_rate": float(row["sla_rate_median"]),
                    "timeout_rate": float(row["timeout_rate_median"]),
                    "safety_escalation_rate": float(
                        row["safety_escalation_rate_median"]
                    ),
                    "meets_adequacy_envelope": meets,
                    "carbon_vs_green_route_pct": (
                        (carbon - green_carbon) / green_carbon * 100.0
                    ),
                    "adequacy_gap_pp": (adequacy - floor) * 100.0,
                }
            )
    return pd.DataFrame(rows)


def operating_regime_analysis(
    results: pd.DataFrame, draws: pd.DataFrame
) -> pd.DataFrame:
    """Locate the conditions under which dynamic routing earns its complexity.

    Answers reviewer R3-M4: compares Green-Route against the static
    fixed-complexity threshold policy realisation by realisation, and reports
    the exchange rate between the extra operational carbon Green-Route spends
    and the extra modelled service adequacy it delivers, binned by the
    conditions the reviewer named.
    """
    keys = ["scenario", "draw", "replication"]
    green = results[results.strategy == "green_route"]
    static = results[results.strategy == "fixed_threshold"]
    merged = green.merge(static, on=keys, suffixes=("_green", "_static"))
    merged = merged.merge(draws, on="draw", how="left")
    merged["carbon_delta_kg"] = (
        merged.operational_carbon_kg_green - merged.operational_carbon_kg_static
    )
    merged["carbon_premium_pct"] = (
        merged.carbon_delta_kg / merged.operational_carbon_kg_static * 100.0
    )
    merged["adequacy_gain_pp"] = (
        merged.adequacy_rate_green - merged.adequacy_rate_static
    ) * 100.0
    merged["sla_gain_pp"] = (
        merged.sla_rate_green - merged.sla_rate_static
    ) * 100.0
    # kg CO2e per day bought per additional percentage point of modelled
    # adequacy. Undefined where the adequacy gain is negligible.
    merged["exchange_rate"] = np.where(
        merged.adequacy_gain_pp.abs() > 1e-6,
        merged.carbon_delta_kg / merged.adequacy_gain_pp,
        np.nan,
    )
    # Grid contrast is the condition that gives carbon-aware routing something
    # to exploit: when the two grids are alike, there is no reversal to find.
    merged["grid_contrast"] = (
        merged.edge_ci - merged.cloud_ci
    ).abs() / merged[["edge_ci", "cloud_ci"]].min(axis=1)
    merged["queue_pressure"] = merged.p95_wait_s_static

    def tercile(series: pd.Series) -> pd.Series:
        return pd.qcut(
            series, 3, labels=["low", "mid", "high"], duplicates="drop"
        )

    merged["grid_contrast_band"] = tercile(merged.grid_contrast)
    merged["queue_pressure_band"] = tercile(merged.queue_pressure)
    merged["volume_band"] = tercile(merged.volume_multiplier)
    rows: list[dict[str, Any]] = []
    for axis in ("grid_contrast_band", "queue_pressure_band", "volume_band"):
        for band, group in merged.groupby(axis, observed=True):
            rows.append(
                {
                    "axis": axis,
                    "band": str(band),
                    "n": int(group.shape[0]),
                    "carbon_premium_pct_median": float(
                        group.carbon_premium_pct.median()
                    ),
                    "adequacy_gain_pp_median": float(
                        group.adequacy_gain_pp.median()
                    ),
                    "sla_gain_pp_median": float(group.sla_gain_pp.median()),
                    "exchange_rate_median": float(
                        group.exchange_rate.median()
                    ),
                    "reversal_rate_median": float(
                        group.carbon_reversal_rate_green.median()
                    ),
                }
            )
    for scenario, group in merged.groupby("scenario"):
        rows.append(
            {
                "axis": "scenario",
                "band": scenario,
                "n": int(group.shape[0]),
                "carbon_premium_pct_median": float(
                    group.carbon_premium_pct.median()
                ),
                "adequacy_gain_pp_median": float(group.adequacy_gain_pp.median()),
                "sla_gain_pp_median": float(group.sla_gain_pp.median()),
                "exchange_rate_median": float(group.exchange_rate.median()),
                "reversal_rate_median": float(
                    group.carbon_reversal_rate_green.median()
                ),
            }
        )
    return pd.DataFrame(rows)


def write_baseline_assets(
    summary: pd.DataFrame,
    results: pd.DataFrame,
    draws: pd.DataFrame,
    output_dir: Path,
) -> None:
    """Emit the envelope table, the regime table and their LaTeX macros."""
    tables_dir = output_dir / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)
    envelope = envelope_comparison(summary)
    envelope.to_csv(output_dir / "envelope_comparison.csv", index=False)
    regimes = operating_regime_analysis(results, draws)
    regimes.to_csv(output_dir / "operating_regimes.csv", index=False)

    lines = [
        "\\begin{table}[tbp]",
        "\\caption{Green-Route against the strongest practical alternatives. "
        "The adequacy envelope is Green-Route's own median modelled service "
        "adequacy in that scenario; a strategy meets the envelope if it "
        "reaches at least that value. Carbon is compared only among strategies "
        "that do; this is a post hoc comparison at fixed policy settings, not a matched-target optimisation. SLA met denotes response-time compliance. The perfect-information oracle is reported for reference and "
        "is not deployable}",
        "\\label{tab:envelope}",
        "\\centering",
        "\\scriptsize",
        "\\setlength{\\tabcolsep}{2pt}",
        "\\begin{tabular}{>{\\raggedright\\arraybackslash}p{1.55cm}>{\\raggedright\\arraybackslash}p{1.7cm}"
        ">{\\centering\\arraybackslash}p{1.25cm}"
        ">{\\centering\\arraybackslash}p{1.4cm}"
        ">{\\centering\\arraybackslash}p{1.05cm}"
        ">{\\centering\\arraybackslash}p{1.15cm}"
        ">{\\centering\\arraybackslash}p{1.35cm}}",
        "\\toprule",
        "Scenario & Strategy & Carbon (kg/day) & Modelled adequacy & Meets "
        "envelope & Carbon vs GR & SLA met (\\%)\\\\",
        "\\midrule",
    ]
    order = (
        "green_route",
        "mid_default",
        "fixed_threshold",
        "quality_cascade",
        "large_only",
        "oracle",
    )
    for scenario in SCENARIOS:
        label = SCENARIOS[scenario]["label"]
        frame = envelope[envelope["scenario"] == scenario].set_index("strategy")
        for index, strategy in enumerate(order):
            row = frame.loc[strategy]
            scenario_cell = label if index == 0 else ""
            name = STRATEGY_LABELS[strategy]
            if strategy == "oracle":
                name += " (ref.)"
            meets = "yes" if bool(row["meets_adequacy_envelope"]) else "no"
            delta = float(row["carbon_vs_green_route_pct"])
            delta_cell = "--" if strategy == "green_route" else f"{delta:+.1f}\\%"
            lines.append(
                f"{scenario_cell} & {name} & "
                f"{float(row['operational_carbon_kg']):.3f} & "
                f"{float(row['adequacy_rate']) * 100.0:.1f}\\% & {meets} & "
                f"{delta_cell} & "
                f"{float(row['sla_rate']) * 100.0:.1f}\\%\\\\"
            )
        lines.append("\\midrule")
    lines[-1] = "\\bottomrule"
    lines += ["\\end{tabular}", "\\end{table}", ""]
    (tables_dir / "envelope_table.tex").write_text(
        "\n".join(lines), encoding="utf-8"
    )

    contrast = regimes[regimes.axis == "grid_contrast_band"].set_index("band")
    pressure = regimes[regimes.axis == "queue_pressure_band"].set_index("band")
    deployable = envelope[envelope.deployable]
    meeting = deployable[deployable.meets_adequacy_envelope]
    cheapest_is_green = 0
    for scenario in SCENARIOS:
        frame = meeting[meeting.scenario == scenario]
        if frame.empty:
            continue
        if (
            frame.sort_values("operational_carbon_kg").iloc[0]["strategy"]
            == "green_route"
        ):
            cheapest_is_green += 1
    def span(frame: pd.DataFrame, column: str, absolute: bool = False) -> str:
        values = frame[column].abs() if absolute else frame[column]
        return f"{float(values.min()):.1f}\\% to {float(values.max()):.1f}\\%"

    large = deployable[deployable.strategy == "large_only"]
    cascade = deployable[deployable.strategy == "quality_cascade"]
    cheaper = deployable[
        deployable.strategy.isin(["mid_default", "fixed_threshold"])
    ]
    macros = [
        "% Automatically generated by green_route_study.py. Do not edit.",
        "\\newcommand{\\EnvelopeLargeOnlyPremium}{"
        + span(large, "carbon_vs_green_route_pct")
        + "}",
        "\\newcommand{\\EnvelopeCascadePremium}{"
        + span(cascade, "carbon_vs_green_route_pct")
        + "}",
        "\\newcommand{\\EnvelopeCascadeAdequacyGap}{"
        f"{float(cascade.adequacy_gap_pp.abs().min()):.1f}"
        " to "
        f"{float(cascade.adequacy_gap_pp.abs().max()):.1f}"
        "}",
        "\\newcommand{\\EnvelopeCheaperSaving}{"
        + span(cheaper, "carbon_vs_green_route_pct", absolute=True)
        + "}",
        "\\newcommand{\\EnvelopeCheaperAdequacyGap}{"
        f"{float(cheaper.adequacy_gap_pp.abs().min()):.1f}"
        " to "
        f"{float(cheaper.adequacy_gap_pp.abs().max()):.1f}"
        "}",
        "\\newcommand{\\EnvelopeScenariosGreenCheapest}{"
        f"{cheapest_is_green}"
        "}",
        "\\newcommand{\\EnvelopeScenarioCount}{" f"{len(SCENARIOS)}" "}",
        "\\newcommand{\\RegimeLowContrastPremium}{"
        f"{float(contrast.loc['low', 'carbon_premium_pct_median']):.1f}\\%"
        "}",
        "\\newcommand{\\RegimeHighContrastPremium}{"
        f"{float(contrast.loc['high', 'carbon_premium_pct_median']):.1f}\\%"
        "}",
        "\\newcommand{\\RegimeLowContrastAdequacyGain}{"
        f"{float(contrast.loc['low', 'adequacy_gain_pp_median']):.1f}"
        "}",
        "\\newcommand{\\RegimeHighContrastAdequacyGain}{"
        f"{float(contrast.loc['high', 'adequacy_gain_pp_median']):.1f}"
        "}",
        "\\newcommand{\\RegimeLowQueuePremium}{"
        f"{float(pressure.loc['low', 'carbon_premium_pct_median']):.1f}\\%"
        "}",
        "\\newcommand{\\RegimeHighQueuePremium}{"
        f"{float(pressure.loc['high', 'carbon_premium_pct_median']):.1f}\\%"
        "}",
        "\\newcommand{\\RegimeLowQueueSlaGain}{"
        f"{float(pressure.loc['low', 'sla_gain_pp_median']):.1f}"
        "}",
        "\\newcommand{\\RegimeHighQueueSlaGain}{"
        f"{float(pressure.loc['high', 'sla_gain_pp_median']):.1f}"
        "}",
        "\\newcommand{\\RegimeLowContrastReversal}{"
        f"{float(contrast.loc['low', 'reversal_rate_median']) * 100.0:.1f}\\%"
        "}",
        "\\newcommand{\\RegimeHighContrastReversal}{"
        f"{float(contrast.loc['high', 'reversal_rate_median']) * 100.0:.1f}\\%"
        "}",
    ]
    (output_dir / "baseline_values.tex").write_text(
        "\n".join(macros) + "\n", encoding="utf-8"
    )


def baseline_analysis(args: argparse.Namespace) -> None:
    """Rebuild the baseline-comparison assets from existing simulation output."""
    output_dir: Path = args.output_dir
    summary = pd.read_csv(output_dir / "simulation_summary.csv")
    results = pd.read_csv(output_dir / "simulation_results.csv")
    draws = pd.read_csv(output_dir / "parameter_draws.csv")
    write_baseline_assets(summary, results, draws, output_dir)
    print(f"Baseline-comparison assets written to {output_dir}")


def _strategy_ordering(frame: pd.DataFrame, column: str, ascending: bool) -> list[str]:
    ordered = frame.sort_values(column, ascending=ascending)
    return list(ordered["strategy"])


def _pareto_nondominated(frame: pd.DataFrame) -> set[str]:
    """Deployable strategies not dominated on (lower carbon, higher adequacy).

    The perfect-information oracle is excluded. It uses latent rather than
    predicted difficulty, which is unavailable to a deployed router. It is
    not a global optimum over all carbon-service policies or queue trajectories.
    """
    frame = frame[frame["strategy"].isin(DEPLOYABLE_STRATEGIES)]
    records = frame[
        ["strategy", "operational_carbon_kg_median", "adequacy_rate_median"]
    ].to_dict("records")
    surviving: set[str] = set()
    for candidate in records:
        dominated = any(
            other["strategy"] != candidate["strategy"]
            and other["operational_carbon_kg_median"]
            <= candidate["operational_carbon_kg_median"]
            and other["adequacy_rate_median"] >= candidate["adequacy_rate_median"]
            and (
                other["operational_carbon_kg_median"]
                < candidate["operational_carbon_kg_median"]
                or other["adequacy_rate_median"] > candidate["adequacy_rate_median"]
            )
            for other in records
        )
        if not dominated:
            surviving.add(str(candidate["strategy"]))
    return surviving


def adequacy_form_sweep(args: argparse.Namespace) -> None:
    """Re-run every strategy under alternative adequacy functional forms.

    Answers reviewer R3-M2: is the strategy ranking an artefact of the shape of
    Eq. (1) rather than of the routing policies themselves?
    """
    calibration = load_calibration(args.calibration)
    output_dir: Path = args.output_dir
    sweep_dir = output_dir / "adequacy_forms"
    sweep_dir.mkdir(parents=True, exist_ok=True)
    draws = parameter_draws(args.draws, args.seed)
    idle_samples_path = args.calibration.parent / "idle_power_samples.csv"
    idle_power_w = (
        float(pd.read_csv(idle_samples_path)["total_w"].mean())
        if idle_samples_path.exists()
        else 1.0
    )
    bin_minutes = 15

    forms = list(args.forms) if args.forms else list(ADEQUACY_FORMS)
    summaries: dict[str, pd.DataFrame] = {}
    for form in forms:
        print(f"=== adequacy form: {form} ===")
        results = run_simulation_rows(
            draws=draws,
            calibration=calibration,
            replications=args.replications,
            seed=args.seed,
            bin_minutes=bin_minutes,
            idle_power_w=idle_power_w,
            workers=args.workers,
            adequacy_form=form,
            progress_label=f"[{form}] ",
        )
        summary = summarise_simulation(results)
        summary.insert(0, "adequacy_form", form)
        summary.to_csv(sweep_dir / f"summary_{form}.csv", index=False)
        summaries[form] = summary

    _finish_form_sweep(summaries, forms, args.baseline_form, output_dir)
    print(f"Adequacy-form sweep written to {sweep_dir}")


def form_stability(args: argparse.Namespace) -> None:
    """Recompute the rank-stability outputs from saved per-form summaries."""
    output_dir: Path = args.output_dir
    sweep_dir = output_dir / "adequacy_forms"
    summaries = {}
    for form in ADEQUACY_FORMS:
        path = sweep_dir / f"summary_{form}.csv"
        if path.exists():
            summaries[form] = pd.read_csv(path)
    if not summaries:
        raise SystemExit(f"no per-form summaries found in {sweep_dir}")
    forms = [form for form in ADEQUACY_FORMS if form in summaries]
    _finish_form_sweep(summaries, forms, args.baseline_form, output_dir)
    print(f"Rank-stability outputs rebuilt in {sweep_dir}")


def _finish_form_sweep(
    summaries: dict[str, pd.DataFrame],
    forms: list[str],
    baseline: str,
    output_dir: Path,
) -> None:
    from scipy.stats import kendalltau, spearmanr

    sweep_dir = output_dir / "adequacy_forms"
    sweep_dir.mkdir(parents=True, exist_ok=True)
    combined = pd.concat(summaries.values(), ignore_index=True)
    combined.to_csv(sweep_dir / "summary_all_forms.csv", index=False)

    if baseline not in summaries:
        raise ValueError(f"baseline form {baseline} was not simulated")

    stability_rows: list[dict[str, Any]] = []
    for scenario in SCENARIOS:
        base_frame = summaries[baseline]
        base_frame = base_frame[base_frame["scenario"] == scenario]
        base_carbon = _strategy_ordering(
            base_frame, "operational_carbon_kg_median", ascending=True
        )
        base_adequacy = _strategy_ordering(
            base_frame, "adequacy_rate_median", ascending=False
        )
        base_pareto = _pareto_nondominated(base_frame)
        for form in forms:
            frame = summaries[form]
            frame = frame[frame["scenario"] == scenario]
            carbon_order = _strategy_ordering(
                frame, "operational_carbon_kg_median", ascending=True
            )
            adequacy_order = _strategy_ordering(
                frame, "adequacy_rate_median", ascending=False
            )
            pareto = _pareto_nondominated(frame)
            carbon_ranks = [base_carbon.index(s) for s in STRATEGIES]
            carbon_ranks_form = [carbon_order.index(s) for s in STRATEGIES]
            adequacy_ranks = [base_adequacy.index(s) for s in STRATEGIES]
            adequacy_ranks_form = [adequacy_order.index(s) for s in STRATEGIES]
            stability_rows.append(
                {
                    "scenario": scenario,
                    "adequacy_form": form,
                    "carbon_order": " > ".join(carbon_order),
                    "adequacy_order": " > ".join(adequacy_order),
                    "carbon_spearman_vs_baseline": float(
                        spearmanr(carbon_ranks, carbon_ranks_form).statistic
                    ),
                    "carbon_kendall_vs_baseline": float(
                        kendalltau(carbon_ranks, carbon_ranks_form).statistic
                    ),
                    "adequacy_spearman_vs_baseline": float(
                        spearmanr(adequacy_ranks, adequacy_ranks_form).statistic
                    ),
                    "adequacy_kendall_vs_baseline": float(
                        kendalltau(adequacy_ranks, adequacy_ranks_form).statistic
                    ),
                    "carbon_order_identical": carbon_order == base_carbon,
                    "adequacy_order_identical": adequacy_order == base_adequacy,
                    "green_route_carbon_rank": carbon_order.index("green_route") + 1,
                    "green_route_adequacy_rank": (
                        adequacy_order.index("green_route") + 1
                    ),
                    "green_route_pareto": "green_route" in pareto,
                    "pareto_set": " ".join(sorted(pareto)),
                    "pareto_set_identical": pareto == base_pareto,
                    "green_route_carbon_kg": float(
                        frame.loc[
                            frame["strategy"] == "green_route",
                            "operational_carbon_kg_median",
                        ].iloc[0]
                    ),
                    "green_route_adequacy": float(
                        frame.loc[
                            frame["strategy"] == "green_route",
                            "adequacy_rate_median",
                        ].iloc[0]
                    ),
                }
            )
    stability = pd.DataFrame(stability_rows)
    stability.to_csv(sweep_dir / "rank_stability.csv", index=False)
    write_adequacy_form_assets(combined, stability, forms, baseline, output_dir)


def write_adequacy_form_assets(
    combined: pd.DataFrame,
    stability: pd.DataFrame,
    forms: list[str],
    baseline: str,
    output_dir: Path,
) -> None:
    """Emit the LaTeX table and macros for the adequacy-form sensitivity."""
    tables_dir = output_dir / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)
    short = {
        "large_only": "LO",
        "mid_default": "MD",
        "fixed_threshold": "FT",
        "quality_cascade": "QC",
        "green_route": "GR",
        "oracle": "OR",
    }
    lines = [
        "\\begin{table}[tbp]",
        "\\caption{Sensitivity of the strategy ranking to the functional form of "
        "the modelled service-adequacy constraint (Eq.~\\ref{eq:adequacy}). "
        "Strategies are ordered from lowest to highest median daily operational "
        "carbon. LO, large-model-only; MD, mid-sized default; FT, "
        "fixed-complexity thresholds; QC, quality-constrained cascade; GR, "
        "Green-Route; OR, perfect-information oracle. $\\rho$ is the Spearman "
        "rank correlation of the carbon ordering against the baseline form}",
        "\\label{tab:adequacy_forms}",
        "\\centering",
        "\\scriptsize",
        "\\setlength{\\tabcolsep}{2pt}",
        "\\begin{tabular}{>{\\raggedright\\arraybackslash}p{1.75cm}>{\\raggedright\\arraybackslash}p{1.75cm}>{\\raggedright\\arraybackslash}p{2.85cm}"
        ">{\\centering\\arraybackslash}p{0.9cm}"
        ">{\\centering\\arraybackslash}p{1.35cm}}",
        "\\toprule",
        "Scenario & Adequacy form & Carbon ordering, cheapest first & "
        "$\\rho$ & GR on frontier\\\\",
        "\\midrule",
    ]
    for scenario in SCENARIOS:
        label = SCENARIOS[scenario]["label"]
        rows = stability[stability["scenario"] == scenario]
        for index, (_, row) in enumerate(rows.iterrows()):
            scenario_cell = label if index == 0 else ""
            form_label = ADEQUACY_FORM_LABELS[row["adequacy_form"]]
            order = " ".join(
                short[s] for s in str(row["carbon_order"]).split(" > ")
            )
            rho = f"{float(row['carbon_spearman_vs_baseline']):.3f}"
            frontier = "yes" if bool(row["green_route_pareto"]) else "no"
            lines.append(
                f"{scenario_cell} & {form_label} & {order} & {rho} & {frontier}\\\\"
            )
        lines.append("\\midrule")
    lines[-1] = "\\bottomrule"
    lines += ["\\end{tabular}", "\\end{table}", ""]
    (tables_dir / "adequacy_form_table.tex").write_text(
        "\n".join(lines), encoding="utf-8"
    )

    alternatives = stability[stability["adequacy_form"] != baseline]
    macros = [
        "% Automatically generated by green_route_study.py. Do not edit.",
        f"\\newcommand{{\\AdequacyFormCount}}{{{len(forms)}}}",
        f"\\newcommand{{\\AdequacyFormAlternatives}}{{{len(forms) - 1}}}",
        "\\newcommand{\\AdequacyFormCells}{"
        f"{int(alternatives.shape[0])}"
        "}",
        "\\newcommand{\\AdequacyFormCarbonOrderIdentical}{"
        f"{int(alternatives['carbon_order_identical'].sum())}"
        "}",
        "\\newcommand{\\AdequacyFormAdequacyOrderIdentical}{"
        f"{int(alternatives['adequacy_order_identical'].sum())}"
        "}",
        "\\newcommand{\\AdequacyFormMinCarbonSpearman}{"
        f"{float(alternatives['carbon_spearman_vs_baseline'].min()):.3f}"
        "}",
        "\\newcommand{\\AdequacyFormMinAdequacySpearman}{"
        f"{float(alternatives['adequacy_spearman_vs_baseline'].min()):.3f}"
        "}",
        "\\newcommand{\\AdequacyFormGreenRouteFrontier}{"
        f"{int(stability['green_route_pareto'].sum())}"
        "}",
        "\\newcommand{\\AdequacyFormTotalCells}{"
        f"{int(stability.shape[0])}"
        "}",
        "\\newcommand{\\AdequacyFormParetoIdentical}{"
        f"{int(alternatives['pareto_set_identical'].sum())}"
        "}",
        "\\newcommand{\\AdequacyFormAdequacySpread}{"
        f"{float(stability['green_route_adequacy'].min()) * 100.0:.1f}\\%"
        " to "
        f"{float(stability['green_route_adequacy'].max()) * 100.0:.1f}\\%"
        "}",
    ]

    # Detail every cell in which Green-Route leaves the deployable frontier, so
    # the manuscript can describe the failure rather than only count it.
    lost = stability[~stability.green_route_pareto.astype(bool)]
    macros.append(
        "\\newcommand{\\AdequacyFormFrontierLosses}{" f"{int(lost.shape[0])}" "}"
    )
    if lost.shape[0] == 1:
        row = lost.iloc[0]
        scenario, form = str(row["scenario"]), str(row["adequacy_form"])
        frame = combined[
            (combined.scenario == scenario) & (combined.adequacy_form == form)
        ].set_index("strategy")
        base = combined[
            (combined.scenario == scenario) & (combined.adequacy_form == baseline)
        ].set_index("strategy")
        macros += [
            "\\newcommand{\\AdequacyFormLossScenario}{"
            f"{SCENARIOS[scenario]['label'].lower()}" "}",
            "\\newcommand{\\AdequacyFormLossForm}{"
            f"{ADEQUACY_FORM_LABELS[form].lower()}" "}",
            "\\newcommand{\\AdequacyFormLossLargeShare}{"
            f"{float(frame.loc['green_route', 'large_share_median']) * 100.0:.1f}\\%"
            "}",
            "\\newcommand{\\AdequacyFormBaseLargeShare}{"
            f"{float(base.loc['green_route', 'large_share_median']) * 100.0:.1f}\\%"
            "}",
            "\\newcommand{\\AdequacyFormLossCarbon}{"
            f"{float(frame.loc['green_route', 'operational_carbon_kg_median']):.3f}"
            "}",
            "\\newcommand{\\AdequacyFormLossLargeOnlyCarbon}{"
            f"{float(frame.loc['large_only', 'operational_carbon_kg_median']):.3f}"
            "}",
            "\\newcommand{\\AdequacyFormLossAdequacy}{"
            f"{float(frame.loc['green_route', 'adequacy_rate_median']) * 100.0:.1f}\\%"
            "}",
            "\\newcommand{\\AdequacyFormLossLargeOnlyAdequacy}{"
            f"{float(frame.loc['large_only', 'adequacy_rate_median']) * 100.0:.1f}\\%"
            "}",
        ]
    (output_dir / "adequacy_form_values.tex").write_text(
        "\n".join(macros) + "\n", encoding="utf-8"
    )


def main() -> None:
    args = parse_args()
    args.function(args)


if __name__ == "__main__":
    main()
