#!/usr/bin/env python3
"""Verification checks for the calibrated Green-Route study."""

from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

import numpy as np
import pandas as pd

import green_route_study as study


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--calibration-dir", type=Path, default=Path("calibration"))
    parser.add_argument("--output-dir", type=Path, default=Path("study_outputs"))
    parser.add_argument("--paper", type=Path, default=Path("paper.tex"))
    parser.add_argument("--draws", type=int, default=200)
    parser.add_argument("--replications", type=int, default=10)
    return parser.parse_args()


def verify_model_and_scenario_definitions() -> None:
    prompts = study.load_prompts(Path("tourism_benchmark_prompts.json"))
    assert len(prompts) == 30
    for scenario, values in study.SCENARIOS.items():
        assert math.isclose(sum(values["complexity"]), 1.0, abs_tol=1e-12), scenario
        assert values["daily_volume"] > 0

    first = study.parameter_draws(10, 42)
    second = study.parameter_draws(10, 42)
    pd.testing.assert_frame_equal(first, second)


def verify_router_invariants() -> None:
    params = pd.Series(
        {
            "ability_shift": 0.0,
            "compact_workers": 3,
            "mid_workers": 8,
            "large_workers": 12,
            "edge_pue": 1.30,
            "cloud_pue": 1.20,
            "mid_network_wh": 0.0002,
            "large_network_wh": 0.0005,
        }
    )
    sampled = {
        tier: {
            complexity: {"energy_wh": energy, "latency_s": 1.0}
            for complexity in study.COMPLEXITIES
        }
        for tier, energy in {
            "compact": 0.003,
            "mid": 0.008,
            "large": 0.020,
        }.items()
    }
    empty_queues = {tier: 0.0 for tier in study.TIER_ORDER}
    tier, _, _ = study.route_request(
        "green_route",
        "simple",
        0.20,
        0.20,
        False,
        empty_queues,
        sampled,
        params,
        edge_ci=0.55,
        cloud_ci=0.04,
        input_token_factor=1.0,
        output_token_factor=1.0,
    )
    assert tier == "mid", "Carbon reversal did not route to cleaner cloud power"
    tier, _, _ = study.route_request(
        "green_route",
        "simple",
        0.20,
        0.20,
        True,
        empty_queues,
        sampled,
        params,
        edge_ci=0.05,
        cloud_ci=0.50,
        input_token_factor=1.0,
        output_token_factor=1.0,
    )
    assert tier == "large", "Safety-critical request did not escalate"


def verify_calibration(calibration_dir: Path) -> None:
    raw_path = calibration_dir / "benchmark_raw.csv"
    calibration_path = calibration_dir / "calibration.json"
    if not raw_path.exists() or not calibration_path.exists():
        raise FileNotFoundError("Calibration outputs are incomplete")
    raw = pd.read_csv(raw_path)
    assert len(raw) == 3 * 5 * 30
    assert set(raw.model_tier) == set(study.TIER_ORDER)
    assert set(raw.repetition) == set(range(1, 6))
    assert (raw.output_tokens > 0).all()
    assert (raw.dynamic_energy_wh >= 0).all()
    assert np.isfinite(raw.wall_seconds).all()
    assert (raw.wall_seconds > 0).all()

    for path in sorted((calibration_dir / "power_logs").glob("*.plist")):
        samples = study.extract_power_samples(path)
        assert len(samples) > 0
        assert (samples.total_w >= 0).all()

    calibration = json.loads(calibration_path.read_text(encoding="utf-8"))
    assert set(calibration["fitted_models"]) == set(study.TIER_ORDER)
    first = study.fit_calibration(raw, 100, 42)
    second = study.fit_calibration(raw, 100, 42)
    assert first == second, "Calibration processing is not deterministic"


def verify_simulation(
    calibration_dir: Path,
    output_dir: Path,
    draws: int,
    replications: int,
) -> None:
    results = pd.read_csv(output_dir / "simulation_results.csv")
    expected_rows = (
        len(study.SCENARIOS)
        * len(study.STRATEGIES)
        * draws
        * replications
    )
    assert len(results) == expected_rows
    assert not results.duplicated(
        ["scenario", "strategy", "draw", "replication"]
    ).any()
    paired_counts = results.groupby(
        ["scenario", "draw", "replication"]
    ).queries.nunique()
    assert (paired_counts == 1).all(), "Strategies did not share arrival streams"

    rate_columns = [
        "adequacy_rate",
        "sla_rate",
        "timeout_rate",
        "failover_rate",
        "carbon_reversal_rate",
        "safety_escalation_rate",
        "compact_share",
        "mid_share",
        "large_share",
    ]
    for column in rate_columns:
        assert results[column].between(0, 1).all(), column
    shares = results[["compact_share", "mid_share", "large_share"]].sum(axis=1)
    assert np.allclose(shares, 1.0)
    assert np.allclose(results.safety_escalation_rate, 1.0)
    assert (results.operational_carbon_kg >= 0).all()
    assert (results.extended_carbon_kg >= results.operational_carbon_kg).all()
    assert (results.unfinished_queue_work_s >= 0).all()
    assert (results.max_queue_s > 0).any(), "Capacity saturation was not exercised"
    assert (results.timeout_rate > 0).any(), "Timeout handling was not exercised"
    assert (results.failover_rate > 0).any(), "Failover handling was not exercised"
    green = results[results.strategy == "green_route"]
    assert (green.carbon_reversal_rate > 0).any(), "Carbon reversal was not exercised"

    expected_stems = [
        "Fig1",
        "Fig2",
        "Fig3",
        "Fig4",
        "Fig5",
        "Fig6",
    ]
    for stem in expected_stems:
        for suffix in ("pdf", "eps", "png"):
            path = output_dir / "figures" / f"{stem}.{suffix}"
            assert path.exists() and path.stat().st_size > 0, path
    assert (output_dir / "manuscript_values.tex").exists()
    for table_name in (
        "scenario_table.tex",
        "uncertainty_table.tex",
        "main_results_table.tex",
    ):
        assert (output_dir / "tables" / table_name).exists()

    calibration = study.load_calibration(calibration_dir / "calibration.json")
    metadata = json.loads(
        (output_dir / "simulation_metadata.json").read_text(encoding="utf-8")
    )
    parameters = pd.read_csv(output_dir / "parameter_draws.csv").iloc[0]
    idle_power_w = float(
        pd.read_csv(calibration_dir / "idle_power_samples.csv")["total_w"].mean()
    )
    regenerated = pd.DataFrame(
        study.simulate_replication_task(
            (
                parameters.to_dict(),
                calibration,
                0,
                int(metadata["seed"]),
                int(metadata["bin_minutes"]),
                idle_power_w,
                1_000,
                study.BASELINE_ADEQUACY_FORM,
            )
        )
    ).sort_values(["scenario", "strategy"]).reset_index(drop=True)
    stored = (
        results[(results["draw"] == 0) & (results["replication"] == 0)]
        .sort_values(["scenario", "strategy"])
        .reset_index(drop=True)
    )
    for column in regenerated.columns:
        if column in {"scenario", "strategy"}:
            assert regenerated[column].equals(stored[column])
        else:
            assert np.allclose(
                regenerated[column].to_numpy(float),
                stored[column].to_numpy(float),
                rtol=1e-12,
                atol=1e-12,
            ), column


def verify_manuscript(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    assert "\u2014" not in text
    assert "---" not in text
    assert "Green-Route: A Calibrated Carbon- and Service-Aware Routing Framework" in text
    assert r"\input{study_outputs/manuscript_values.tex}" in text
    assert r"\input{study_outputs/tables/scenario_table.tex}" in text
    assert r"\input{study_outputs/tables/uncertainty_table.tex}" in text
    assert r"\input{study_outputs/tables/main_results_table.tex}" in text
    assert (
        r"between \SafetyDisruptionAdequacy\ and \FestivalSurgeAdequacy"
        in text
    )
    abstract_start = text.find(r"\abstract{")
    keywords_start = text.find(r"\keywords{")
    assert abstract_start >= 0 and keywords_start > abstract_start, (
        "Abstract was not found"
    )
    abstract_block = text[abstract_start + len(r"\abstract{") : keywords_start]
    abstract_block = abstract_block.rsplit("}", 1)[0]
    # Count the actual numerical content, rather than silently discarding macros.
    macros = {}
    for macro_path in (path.parent / "study_outputs").glob("*values.tex"):
        macros.update(re.findall(
            r"\\newcommand\{\\(\w+)\}\{([^{}]*)\}",
            macro_path.read_text(encoding="utf-8"),
        ))
    for name, value in macros.items():
        abstract_block = re.sub(
            r"\\" + name + r"\b", lambda match: value, abstract_block
        )
    abstract_text = re.sub(r"\\rev\b", "", abstract_block)
    abstract_text = abstract_text.replace(r"\%", "%")
    # Reject unresolved macros rather than undercounting them.
    assert not re.search(r"\\[A-Za-z]+", abstract_text), abstract_text
    abstract_text = re.sub(r"[{}$]|\\", " ", abstract_text)
    abstract_words = len(abstract_text.split())
    assert abstract_words <= 250, f"Expanded abstract: {abstract_words} words"
    print(f"Expanded abstract: {abstract_words} words")
    assert text.count(r"\subsubsection") == 0

    log_path = path.with_suffix(".log")
    if log_path.exists():
        log = log_path.read_text(encoding="utf-8", errors="replace")
        forbidden = [
            "undefined references",
            "Citation `",
            "Reference `",
            "Overfull \\hbox",
        ]
        for marker in forbidden:
            assert marker not in log, marker


def main() -> None:
    args = parse_args()
    verify_model_and_scenario_definitions()
    verify_router_invariants()
    verify_calibration(args.calibration_dir)
    verify_simulation(
        args.calibration_dir,
        args.output_dir,
        args.draws,
        args.replications,
    )
    verify_manuscript(args.paper)
    print("All Green-Route verification checks passed")


if __name__ == "__main__":
    main()
