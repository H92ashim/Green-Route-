# Green-Route supplementary code and data

Updated for the September 2026 revision. The benchmark observations and stored simulation outcomes are unchanged by the final editorial pass. Presentation builders and manuscript verification have been updated.

Install the scientific dependencies from requirements.txt. Run scientific commands from this archive's root:

- python verify_study.py --paper /path/to/revised/paper.tex
- python regenerate_figures.py
- python green_route_study.py form-stability

The manuscript argument must point to the accompanying LaTeX source with its adjacent study_outputs macro files. The complete revision package provides that source. The verification suite regenerates one paired draw/replication as a consistency check, not the full uncertainty study.

The archive includes raw benchmark/power logs, calibration models, baseline per-realisation results, parameter draws and alternative-form summary/rank results. Alternative-form per-realisation records were not retained in the supplied material. To rerun that full study, use python green_route_study.py adequacy-form-sweep.

The response-quality assumptions, demand scenarios and hypothetical hosted-tier roles are not field measurements. See the revised manuscript for transfer assumptions, system boundaries and limits.
