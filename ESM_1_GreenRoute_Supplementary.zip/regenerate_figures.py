#!/usr/bin/env python3
"""Redraw the manuscript figures and tables from existing simulation outputs.

Used for the presentation pass of the revision (R2-2, R3-m5). It reads the
already-written study outputs and calls only the figure and asset-writing
functions, so no simulation is re-run and no reported value can change.
"""

from pathlib import Path

import pandas as pd

import green_route_study as g


def main() -> None:
    output_dir = Path("study_outputs")
    calibration = g.load_calibration(Path("calibration/calibration.json"))
    summary = pd.read_csv(output_dir / "simulation_summary.csv")
    results = pd.read_csv(output_dir / "simulation_results.csv")
    draws = pd.read_csv(output_dir / "parameter_draws.csv")
    break_even = g.break_even_analysis(results, draws)
    g.write_manuscript_assets(calibration, results, summary, break_even, output_dir)
    g.write_baseline_assets(summary, results, draws, output_dir)
    g.configure_figures()
    g.figure_framework(output_dir)
    g.figure_calibration(calibration, output_dir)
    g.figure_strategy_outcomes(summary, output_dir)
    g.figure_queue_sla(summary, output_dir)
    g.figure_pareto(summary, output_dir)
    g.figure_uncertainty(results, break_even, output_dir)
    print(f"Figures and tables regenerated in {output_dir}")


if __name__ == "__main__":
    main()
